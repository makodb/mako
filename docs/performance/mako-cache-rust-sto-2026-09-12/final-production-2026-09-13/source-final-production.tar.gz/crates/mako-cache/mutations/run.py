#!/usr/bin/env python3
"""Strict, source-isolated mutation gate for mako-cache Phase 1F.

The runner never enables a mutation branch in the production crate.  For the
baseline and for every mutant it creates a new temporary Cargo workspace,
copies mako-cache source into it, rewrites path dependencies to absolute paths
back to the original workspace, and uses a distinct initially-empty target
directory.  This makes a green result from a stale original artefact a harness
error rather than evidence.

Progress is written to stderr.  The complete machine-readable report is JSON
on stdout, and may additionally be written with --report.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import dataclasses
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Iterable, Sequence


RUNNER_DIR = Path(__file__).resolve().parent
ORIGINAL_CRATE = RUNNER_DIR.parent
ORIGINAL_CRATES = ORIGINAL_CRATE.parent
ORIGINAL_LOCKFILE = ORIGINAL_CRATES / "Cargo.lock"
ORIGINAL_TOOLCHAIN = ORIGINAL_CRATES.parent / "rust-toolchain.toml"

BASE_CARGO_ARGS = (
    "test",
    "--locked",
    "-p",
    "mako-cache",
)


def cargo_args(engine: str) -> tuple[str, ...]:
    feature = "engine-sto-test-hooks" if engine == "sto" else "engine-c-abi"
    return (*BASE_CARGO_ARGS, "--no-default-features", "--features", f"{feature},test-support")


@dataclasses.dataclass(frozen=True)
class TestTarget:
    cargo_selector: tuple[str, ...]
    exact_name: str
    needs_native: bool = False
    needs_hooks: bool = False

    @property
    def failure_signature(self) -> str:
        return f"test {self.exact_name} ... FAILED"


@dataclasses.dataclass(frozen=True)
class Mutation:
    name: str
    relative_path: str
    anchor: str
    anchor_sha256: str
    replacement: str
    test: TestTarget
    breaks: str


WRITEBACK_UNIT = lambda name: TestTarget(
    ("--lib",), f"writeback::tests::{name}"
)
LIB_UNIT_NATIVE = lambda name: TestTarget(
    ("--lib",), f"tests::{name}", needs_native=True
)
NATIVE_INTEGRATION = lambda name: TestTarget(
    ("--test", "native"), name, needs_native=True
)


ACCEPTANCE_NATIVE = lambda name: TestTarget(
    ("--lib",), f"milestone1_acceptance_tests::{name}", needs_native=True
)


MUTATIONS: tuple[Mutation, ...] = (
    Mutation(
        name="read-only-registration-bound-before-cut",
        relative_path="src/lib.rs",
        anchor="""    fn read_only_scan_bound(&self, order_validation_prefix: impl FnOnce()) -> usize {
        order_validation_prefix();
        // A prefix writer registered its slot before its packed Release RMW.
        // The cut acquires that publication or its release sequence. Loading
        // the monotone registration counter AFTER that cut therefore includes
        // every prefix writer, even though registration itself was Relaxed.
        // An Acquire load before the cut would not establish this guarantee.
        // Slots are never reused and this counter never decreases or resets.
        NEXT_COMMIT_FENCE_THREAD_SLOT.load(Ordering::Acquire)
    }
""",
        anchor_sha256="01d39a283d41d8462f2062ffb3763d96fac0702c68aeaeae88b3db10facd5882",
        replacement="""    fn read_only_scan_bound(&self, order_validation_prefix: impl FnOnce()) -> usize {
        // MUTANT: an early bound can omit a writer included by the later cut.
        let registered = NEXT_COMMIT_FENCE_THREAD_SLOT.load(Ordering::Acquire);
        order_validation_prefix();
        registered
    }
""",
        test=TestTarget(
            ("--lib",),
            "tests::commit_fence_scan_bound_includes_registration_completed_inside_cut",
        ),
        breaks=(
            "A prefix writer registered during the cut is omitted from "
            "the reader's scan."
        ),
    ),
    Mutation(
        name="native-replay-drops-put-value",
        relative_path="src/record.rs",
        anchor="""                PUT_TAG => {
                    let value = cursor.take(value_len)?;
                    parsed.push(ParsedMutation::Put {
                        table_id,
                        key,
                        value,
                    });
                }
""",
        anchor_sha256="d0883774d9a0de40a3427a643047cbf5ea300aaaed3d903d89bcbe11119a717f",
        replacement="""                PUT_TAG => {
                    let value = cursor.take(value_len)?;
                    // MUTANT: replay every native put as an empty value.
                    parsed.push(ParsedMutation::Put {
                        table_id,
                        key,
                        value: &value[..0],
                    });
                }
""",
        test=NATIVE_INTEGRATION(
            "every_same_key_mutation_pair_has_one_canonical_backend_result"
        ),
        breaks=(
            "The native transaction installs the canonical final same-key value "
            "while asynchronous RocksDB replay materializes an empty value."
        ),
    ),
    Mutation(
        name="early-detached-capacity-discharge",
        relative_path="src/writeback.rs",
        anchor="""        permit.prepared = Some(Box::new(LegacyCommitRecord::prepare(
            mutations,
            self.config.max_record_bytes,
        )?));
        Ok(permit)
""",
        anchor_sha256="d6888cd1a604c60cdaa0f1a97573a9729075ad7ea5bc54953396cbd9143c92ed",
        replacement="""        permit.prepared = Some(Box::new(LegacyCommitRecord::prepare(
            mutations,
            self.config.max_record_bytes,
        )?));
        // MUTANT: advertise capacity while the detached permit still exists.
        permit.owns_claim = false;
        self.release_detached_claim(None);
        Ok(permit)
""",
        test=WRITEBACK_UNIT(
            "detached_permit_backpressures_another_reserver_until_drop"
        ),
        breaks=(
            "A second producer can enter a capacity-one queue before the first "
            "detached reservation is consumed or dropped."
        ),
    ),
    Mutation(
        name="hook-time-allocation",
        relative_path="src/writeback.rs",
        anchor="""        assert!(self.owns_claim, "binding must own a detached claim");
        // Legacy preparation remains boxed through the ordered hook. Its large
""",
        anchor_sha256="3e33505a4c3715689a4a27e13a387d0d4b96bdddf838b4ce5ef53a99882a199e",
        replacement="""        assert!(self.owns_claim, "binding must own a detached claim");
        // MUTANT: allocate while Silo's post-validation hook holds write locks.
        let hook_allocation = Box::new(mako_timestamp.to_be_bytes());
        std::hint::black_box(&hook_allocation);
        drop(hook_allocation);
        // Legacy preparation remains boxed through the ordered hook. Its large
""",
        test=TestTarget(
            ("--test", "hook_allocation"),
            "detached_bind_is_allocation_free_and_the_tripwire_is_live",
        ),
        breaks=(
            "DetachedPermit::bind performs a heap round trip in the native "
            "post-validation critical section."
        ),
    ),
    Mutation(
        name="conflict-cancellation-slot",
        relative_path="src/writeback.rs",
        anchor="""        } else {
            self.occupied.release();
            self.notify_capacity_release();
        }
""",
        anchor_sha256="fab75e41259f2c51141e60ecc98a3f29e6ff657d425cc37ca082bb200e7cdf35",
        replacement="""        } else {
            // MUTANT: turn a pre-validation abort into a cancelled log position.
            let cancelled = self
                .next_bound
                .fetch_update(Ordering::AcqRel, Ordering::Acquire, |current| {
                    current.checked_add(1)
                })
                .expect("mutant cancellation sequence exhausted")
                + 1;
            let mut state = lock_recover(&self.state);
            state.last_bound = cancelled;
            drop(state);
            self.occupied.release();
            self.notify_capacity_release();
        }
""",
        test=WRITEBACK_UNIT(
            "detached_abort_uses_capacity_but_never_assigns_a_sequence_or_slot"
        ),
        breaks=(
            "A validation loser advances last_bound and leaves a gap in the "
            "dense committed CacheSeq history."
        ),
    ),
    Mutation(
        name="missing-ready-publication",
        relative_path="src/writeback.rs",
        anchor="""        self.publication_cell(sequence)
            .publish_attached(sequence, self.publication_shift);
        self.finish_ready_publication(token)
""",
        anchor_sha256="a174de5042bfcd9b4174be299b053339b6679770a87cd98f02ea7631c779bfa7",
        replacement="""        // MUTANT: acknowledge without publishing the completed record cell.
        self.acknowledged.store(sequence.get(), Ordering::Release);
        Ok(())
""",
        test=WRITEBACK_UNIT(
            "bind_and_publish_make_the_prepared_to_ready_transition_explicit"
        ),
        breaks=(
            "A successful publish advances the acknowledged frontier but leaves "
            "the write-back consumer permanently blocked."
        ),
    ),
    Mutation(
        name="premature-ready-publication",
        relative_path="src/writeback.rs",
        anchor="""            state.queue.push_back(Slot {
                sequence,
                record: None,
                state: SlotState::Prepared { pinned: false },
            });
""",
        anchor_sha256="e7d3403c850a828f34a4ecd59253a7e30fd97ef5e353c86329f617394bdf5455",
        replacement="""            state.queue.push_back(Slot {
                sequence,
                record: None,
                // MUTANT: expose Ready before the finalized record exists.
                state: SlotState::Ready,
            });
""",
        test=WRITEBACK_UNIT(
            "bind_and_publish_make_the_prepared_to_ready_transition_explicit"
        ),
        breaks=(
            "The consumer may observe Ready before native success and before the "
            "finalized record has been stored."
        ),
    ),
    Mutation(
        name="unpinned-unknown-outcome",
        relative_path="src/writeback.rs",
        anchor="""        Ok(BoundReservation {
            owner: self.owner,
            token: QueueToken::new(sequence),
            mako_timestamp,
            payload,
            on_drop: DropAction::PinUnknown,
        })
""",
        anchor_sha256="293a2c63db4f50c83a596511388767d05dc316a9968b5ae88548e5c6cf4fff15",
        replacement="""        Ok(BoundReservation {
            owner: self.owner,
            token: QueueToken::new(sequence),
            mako_timestamp,
            payload,
            // MUTANT: silently discard an ambiguous post-bind outcome.
            on_drop: DropAction::Done,
        })
""",
        test=WRITEBACK_UNIT(
            "dropping_bound_unknown_finalizes_and_retains_its_write_set"
        ),
        breaks=(
            "Dropping a bound reservation neither finalizes its record nor pins "
            "the uncertain sequence, permitting unsafe progress."
        ),
    ),
    Mutation(
        name="checkpoint-load-omits-values",
        relative_path="src/recovery.rs",
        anchor="""        let mut txn = local.transaction()?;
        txn.put(&table, raw, value)?;
        let report = txn.commit_report();
""",
        anchor_sha256="7e61f206f2eb2eb168fa25e1025f7994da733b25099b06fe9754bd3b5952cb94",
        replacement="""        let mut txn = local.transaction()?;
        // MUTANT: count the current row without loading its value into Silo.
        let _ = (&table, raw, value);
        let report = txn.commit_report();
""",
        test=ACCEPTANCE_NATIVE(
            "gc_reclaims_all_history_then_recovers_current_values_tombstones_and_counters"
        ),
        breaks="Checkpoint startup exposes missing live values after their logs were reclaimed.",
    ),
    Mutation(
        name="checkpoint-hydrates-tombstones",
        relative_path="src/recovery.rs",
        anchor="""        let Some(value) = row.value else {
            return Ok(());
        };
""",
        anchor_sha256="0fd841b62ed4ce30d332dd88f1f2a02e83efc32acbe17e119ef668640ca56b8e",
        replacement="""        // MUTANT: turn a persisted tombstone into a present empty value.
        let value = row.value.unwrap_or(&[]);
""",
        test=ACCEPTANCE_NATIVE(
            "gc_reclaims_all_history_then_recovers_current_values_tombstones_and_counters"
        ),
        breaks="Checkpoint hydration makes a deleted key present in Silo.",
    ),
    Mutation(
        name="wrong-mako-timestamp",
        relative_path="src/writeback.rs",
        anchor="""            state
                .applied
                .advance(record.sequence(), record.mako_timestamp());
""",
        anchor_sha256="fcb53f319fe853c829e15edcba94840e62665bcd85b540b512bc66821b5626ab",
        replacement="""            // MUTANT: advance the frontier with a valid but different timestamp.
            let record_timestamp = record.mako_timestamp();
            let wrong_timestamp = MakoTimestamp::new(
                record_timestamp.physical_us(),
                record_timestamp.logical(),
                if record_timestamp.origin() == u32::MAX {
                    1
                } else {
                    record_timestamp.origin() + 1
                },
            )
            .expect("mutant timestamp retains a nonzero origin");
            state.applied.advance(record.sequence(), wrong_timestamp);
""",
        test=TestTarget(
            ("--test", "timestamp"),
            "native_timestamp_matches_the_persisted_record_and_applied_frontier",
            needs_native=True,
            needs_hooks=True,
        ),
        breaks=(
            "The applied frontier no longer agrees with the exact Mako "
            "timestamp encoded by native serialization."
        ),
    ),
    Mutation(
        name="missing-recovery-clock-floor",
        relative_path="src/recovery.rs",
        anchor="""    if let Some(timestamp) = recovered.maximum_timestamp {
        #[cfg(test)]
        crate::failpoint::hit(crate::failpoint::Point::RecoveryBeforeClockFloor);
        mako_engine::advance_mako_timestamp_past(timestamp)?;
        #[cfg(test)]
        crate::failpoint::hit(crate::failpoint::Point::RecoveryAfterClockFloor);
    }
""",
        anchor_sha256="c8a583353e4b2f7b63232783cfe21183e8c15fe20eedb7324208b8604be70fec",
        replacement="""    if let Some(timestamp) = recovered.maximum_timestamp {
        #[cfg(test)]
        crate::failpoint::hit(crate::failpoint::Point::RecoveryBeforeClockFloor);
        // MUTANT: expose recovery without advancing the process-wide clock.
        let _ = timestamp;
        #[cfg(test)]
        crate::failpoint::hit(crate::failpoint::Point::RecoveryAfterClockFloor);
    }
""",
        test=LIB_UNIT_NATIVE(
            "recovery_advances_mako_timestamp_past_the_recovered_maximum"
        ),
        breaks=(
            "A post-recovery native commit can reuse or precede a timestamp in "
            "the recovered backend history."
        ),
    ),
    Mutation(
        name="gc-includes-exact-cutoff",
        relative_path="src/writeback.rs",
        anchor="""                    if record.mako_timestamp().physical_us() >= cutoff_us {
""",
        anchor_sha256="e88e14a99a1bfbf65b23461e86ffb4a640df905182e01a75bea362c7b034419d",
        replacement="""                    // MUTANT: expire a record exactly at the configured age boundary.
                    if record.mako_timestamp().physical_us() > cutoff_us {
""",
        test=WRITEBACK_UNIT("gc_cutoff_is_strict_and_untagged_reversed_hlc_keeps_dense_suffix"),
        breaks="GC deletes records at the retention boundary instead of retaining them.",
    ),
    Mutation(
        name="gc-loses-reclaimed-metadata",
        relative_path="src/writeback.rs",
        anchor="""                let count = operations.len() as u64;
                operations.push(OwnedOperation::Put(
                    checkpoint::lane_key(lane as u16),
                    metadata.encode()?,
                ));
""",
        anchor_sha256="89950aa45819b80f2c8c964050246784b46754e53f31f984a8176437bae131b9",
        replacement="""                let count = operations.len() as u64;
                // MUTANT: delete log keys without persisting their reclaimed frontier.
""",
        test=WRITEBACK_UNIT("gc_cutoff_is_strict_and_untagged_reversed_hlc_keeps_dense_suffix"),
        breaks="GC leaves a gap in the retained suffix by omitting its atomic metadata update.",
    ),
    Mutation(
        name="gc-drops-exact-retry-exclusion",
        relative_path="src/writeback.rs",
        anchor="""        let first = *sequences.first().expect("nonempty apply batch");
        if let Some(pending) = &state.pending {
""",
        anchor_sha256="5d36963da2ae7dd3e7608a274ce39c8edb17e90814ca2138eedce29e91888106",
        replacement="""        let first = *sequences.first().expect("nonempty apply batch");
        // MUTANT: discard ambiguous GC state and let application replace its metadata.
        if matches!(state.pending.as_ref().map(|pending| &pending.kind), Some(PendingKind::Gc { .. })) {
            state.pending = None;
        }
        if let Some(pending) = &state.pending {
""",
        test=WRITEBACK_UNIT("ambiguous_gc_retries_exact_bytes_before_apply_and_counts_once"),
        breaks="An apply can overwrite lane metadata before the exact ambiguous GC retry completes.",
    ),
)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def source_files(crate: Path = ORIGINAL_CRATE) -> list[Path]:
    roots = [crate / "Cargo.toml", crate / "build.rs"]
    for directory in (crate / "src", crate / "tests"):
        if directory.exists():
            roots.extend(path for path in directory.rglob("*") if path.is_file())
    return sorted(path for path in roots if path.exists())


def source_hashes() -> dict[str, str]:
    return {
        path.relative_to(ORIGINAL_CRATE).as_posix(): sha256_bytes(path.read_bytes())
        for path in source_files()
    }


def dependency_hashes() -> dict[str, str]:
    # These remain path dependencies of every isolated copy. A storage adapter
    # change during the run must invalidate the evidence just like a cache edit.
    crates = (
        "mrx-core", "mrx-rocks", "mako-history", "mako-local", "mako-local-sys",
        "mako-engine", "mako-engine-api", "mako-engine-sto", "mako-clock",
        "sto-core", "sto-masstree", "masstree", "mtree-sys",
    )
    files = [path for name in crates for path in source_files(ORIGINAL_CRATES / name)]
    files.append(ORIGINAL_LOCKFILE)
    hashes = {
        path.relative_to(ORIGINAL_CRATES).as_posix(): sha256_bytes(path.read_bytes())
        for path in sorted(files)
    }
    hashes["../rust-toolchain.toml"] = sha256_bytes(ORIGINAL_TOOLCHAIN.read_bytes())
    return hashes


def tree_digest(hashes: dict[str, str]) -> str:
    canonical = "".join(f"{path}\0{digest}\n" for path, digest in sorted(hashes.items()))
    return sha256_text(canonical)


def validate_definitions(selected: Sequence[Mutation]) -> list[dict[str, object]]:
    errors: list[str] = []
    names = [mutation.name for mutation in MUTATIONS]
    duplicates = sorted({name for name in names if names.count(name) > 1})
    if duplicates:
        errors.append(f"duplicate mutation names: {duplicates}")

    validations: list[dict[str, object]] = []
    for mutation in selected:
        target = ORIGINAL_CRATE / mutation.relative_path
        actual_anchor_digest = sha256_text(mutation.anchor)
        source = target.read_text(encoding="utf-8") if target.exists() else ""
        matches = source.count(mutation.anchor)
        replacement_matches = source.count(mutation.replacement)
        valid = True
        reasons: list[str] = []
        if actual_anchor_digest != mutation.anchor_sha256:
            valid = False
            reasons.append(
                "declared anchor SHA256 does not match the runner's anchor bytes: "
                f"declared={mutation.anchor_sha256}, actual={actual_anchor_digest}"
            )
        if matches != 1:
            valid = False
            reasons.append(f"anchor must match exactly once, found {matches}")
        if mutation.anchor == mutation.replacement:
            valid = False
            reasons.append("replacement equals anchor")
        if replacement_matches:
            valid = False
            reasons.append(
                f"replacement already occurs {replacement_matches} time(s) in original source"
            )
        validations.append(
            {
                "name": mutation.name,
                "path": mutation.relative_path,
                "anchor_sha256": mutation.anchor_sha256,
                "anchor_matches": matches,
                "replacement_matches": replacement_matches,
                "valid": valid,
                "reasons": reasons,
            }
        )
        errors.extend(f"{mutation.name}: {reason}" for reason in reasons)

    if not ORIGINAL_LOCKFILE.is_file():
        errors.append(f"workspace lockfile is missing: {ORIGINAL_LOCKFILE}")
    if errors:
        raise HarnessFailure("definition validation failed", details=errors)
    return validations


class HarnessFailure(RuntimeError):
    def __init__(self, message: str, *, details: object | None = None):
        super().__init__(message)
        self.details = details


@dataclasses.dataclass
class TempWorkspace:
    root: Path
    crate: Path
    target: Path
    cleanup: tempfile.TemporaryDirectory[str] | None

    def close(self) -> None:
        if self.cleanup is not None:
            self.cleanup.cleanup()


PATH_DEPENDENCY = re.compile(r'(?P<prefix>\bpath\s*=\s*)"(?P<path>[^"]+)"')


def wrapper_hashes(crate: Path) -> dict[str, str]:
    """Hash both unchanged Rust FFI crates and their direct native headers.

    A source-path override permits using an existing fingerprinted native build
    at its original source root. It does not permit substituting wrapper code,
    ABI headers, or the verifier. Cargo still runs the unchanged mandatory
    source/configuration/archive fingerprint check for every native build.
    """
    root = crate.parent.parent
    if crate.resolve() != root.joinpath("crates/mako-local").resolve():
        raise HarnessFailure("native wrapper override must name the proved crates/mako-local directory")
    files: list[Path] = []
    for relative in ("crates/mako-local", "crates/mako-local-sys"):
        directory = root / relative
        if not directory.joinpath("Cargo.toml").is_file():
            raise HarnessFailure(f"native wrapper source is incomplete: {directory}")
        files.extend(
            path for path in directory.rglob("*") if path.is_file()
            and not any(part in ("target", ".git", "__pycache__") for part in path.relative_to(directory).parts)
            and path.suffix != ".pyc"
        )
    for relative in (
        "src/mako/storage/mako_local_abi.h",
        "src/mako/storage/mako_timestamp.h",
        "scripts/mako_local_fingerprint.py",
    ):
        path = root / relative
        if not path.is_file():
            raise HarnessFailure(f"native wrapper input is missing: {path}")
        files.append(path)
    return {path.relative_to(root).as_posix(): sha256_bytes(path.read_bytes()) for path in sorted(files)}


def verify_wrapper_override(value: str | None) -> tuple[Path | None, dict[str, object] | None]:
    if value is None:
        return None, None
    chosen = Path(value).expanduser().resolve()
    original = ORIGINAL_CRATES / "mako-local"
    current = wrapper_hashes(original)
    alternate = wrapper_hashes(chosen)
    mismatches = sorted(path for path in set(current) | set(alternate)
                        if current.get(path) != alternate.get(path))
    if mismatches:
        raise HarnessFailure("native wrapper source override is not byte-identical", details=mismatches)
    return chosen, {
        "original": str(original), "selected": str(chosen),
        "tree_sha256": tree_digest(current), "file_sha256": current,
        "byte_identical": True, "native_fingerprint_required": True,
    }


def rewrite_path_dependencies(manifest: Path, local_source: Path | None = None) -> list[dict[str, str]]:
    source = manifest.read_text(encoding="utf-8")
    rewrites: list[dict[str, str]] = []

    def replace(match: re.Match[str]) -> str:
        raw = match.group("path")
        dependency = (ORIGINAL_CRATE / raw).resolve()
        if local_source is not None and dependency == (ORIGINAL_CRATES / "mako-local").resolve():
            dependency = local_source
        if not dependency.joinpath("Cargo.toml").is_file():
            raise HarnessFailure(
                f"path dependency {raw!r} does not resolve to a crate",
                details=str(dependency),
            )
        rewrites.append({"from": raw, "to": str(dependency)})
        escaped = str(dependency).replace("\\", "\\\\").replace('"', '\\"')
        return f'{match.group("prefix")}"{escaped}"'

    rewritten = PATH_DEPENDENCY.sub(replace, source)
    if not rewrites:
        raise HarnessFailure("mako-cache manifest has no path dependencies to isolate")
    manifest.write_text(rewritten, encoding="utf-8")
    return rewrites


def create_workspace(
    label: str, keep: bool, temp_root: Path, local_source: Path | None = None
) -> tuple[TempWorkspace, list[dict[str, str]]]:
    temp_root.mkdir(parents=True, exist_ok=True)
    if keep:
        root = Path(
            tempfile.mkdtemp(prefix=f"mako-cache-mut-{label}-", dir=temp_root)
        )
        cleanup = None
    else:
        holder: tempfile.TemporaryDirectory[str] = tempfile.TemporaryDirectory(
            prefix=f"mako-cache-mut-{label}-", dir=temp_root
        )
        root = Path(holder.name)
        cleanup = holder

    crate = root / "mako-cache"
    shutil.copytree(
        ORIGINAL_CRATE,
        crate,
        ignore=shutil.ignore_patterns("target", ".git", "__pycache__", "*.pyc"),
    )
    rewrites = rewrite_path_dependencies(crate / "Cargo.toml", local_source)
    (root / "Cargo.toml").write_text(
        """[workspace]
resolver = "2"
members = ["mako-cache"]

[profile.release]
lto = false
panic = "abort"
codegen-units = 1
opt-level = 3

[profile.dev]
lto = false
""",
        encoding="utf-8",
    )
    shutil.copy2(ORIGINAL_LOCKFILE, root / "Cargo.lock")
    # Temporary workspaces must retain the repo's compiler selection, too.
    shutil.copy2(ORIGINAL_TOOLCHAIN, root / "rust-toolchain.toml")
    target = root / "cargo-target-empty"
    if target.exists():
        raise HarnessFailure(f"new target directory unexpectedly exists: {target}")
    return TempWorkspace(root, crate, target, cleanup), rewrites


def command_display(command: Sequence[str]) -> str:
    # JSON command arrays are authoritative; this form is only for progress.
    return " ".join(command)


def command_result(
    command: Sequence[str],
    *,
    cwd: Path,
    env: dict[str, str],
    timeout: int,
) -> dict[str, object]:
    started = time.monotonic()
    try:
        completed = subprocess.run(
            list(command),
            cwd=cwd,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            check=False,
        )
        timed_out = False
        stdout = completed.stdout
        stderr = completed.stderr
        returncode: int | None = completed.returncode
    except subprocess.TimeoutExpired as error:
        timed_out = True
        stdout = error.stdout.decode() if isinstance(error.stdout, bytes) else (error.stdout or "")
        stderr = error.stderr.decode() if isinstance(error.stderr, bytes) else (error.stderr or "")
        returncode = None
    elapsed = time.monotonic() - started
    combined = stdout + stderr
    running_test_counts = [
        int(match) for match in re.findall(r"(?m)^running (\d+) tests?\s*$", combined)
    ]
    failed_test_lines = [
        line.strip()
        for line in combined.splitlines()
        if line.startswith("test ") and line.rstrip().endswith(" FAILED")
    ]
    return {
        "command": list(command),
        "cwd": str(cwd),
        "timeout_seconds": timeout,
        "timed_out": timed_out,
        "returncode": returncode,
        "elapsed_seconds": round(elapsed, 3),
        "output_sha256": sha256_text(combined),
        "output_tail": combined[-6000:],
        # Cargo emits warnings on stderr after libtest's useful stdout when
        # these streams are captured separately. Preserve both tails so a
        # failing assertion cannot disappear behind repeated build warnings.
        "stdout_tail": stdout[-12000:],
        "stderr_tail": stderr[-6000:],
        "running_test_counts": running_test_counts,
        "failed_test_lines": failed_test_lines,
    }


def cargo_environment(
    workspace: TempWorkspace,
    *,
    native_build: Path | None,
    require_hooks: bool,
) -> dict[str, str]:
    env = os.environ.copy()
    env["CARGO_TARGET_DIR"] = str(workspace.target)
    if native_build is not None:
        env["MAKO_LOCAL_FAKE_ABI"] = "0"
        env["MAKO_BUILD_DIR"] = str(native_build)
        env["MAKO_LOCAL_REQUIRE_NATIVE"] = "1"
    else:
        # mako-local lives at its original absolute path and would otherwise
        # auto-discover a possibly stale default CMake tree there. Pure-Rust
        # mutants intentionally compile against its explicit fake ABI.
        env["MAKO_LOCAL_FAKE_ABI"] = "1"
        env.pop("MAKO_BUILD_DIR", None)
        env.pop("MAKO_LOCAL_REQUIRE_NATIVE", None)
    if require_hooks:
        env["MAKO_CACHE_REQUIRE_NATIVE_CRASH_HOOKS"] = "1"
    else:
        env.pop("MAKO_CACHE_REQUIRE_NATIVE_CRASH_HOOKS", None)
    return env


def prepare_lockfile(
    args: argparse.Namespace,
    workspace: TempWorkspace,
    env: dict[str, str],
) -> dict[str, object]:
    """Normalize the copied full-workspace lock to the one-member topology.

    Cargo records dev-dependency edges for every workspace member.  Once only
    mako-cache is copied, dependencies such as mako-local are ordinary path
    dependencies and their dev-only edges disappear.  Cargo therefore refuses
    the byte-for-byte full-workspace lock under --locked even though every
    resolved registry version is already pinned.  One offline metadata pass
    performs that topology-only normalization; every compile/test after it is
    still --locked.
    """

    lockfile = workspace.root / "Cargo.lock"
    copied_sha = sha256_bytes(lockfile.read_bytes())
    command = [
        args.cargo,
        "metadata",
        "--offline",
        "--format-version",
        "1",
    ]
    result = command_result(
        command,
        cwd=workspace.root,
        env=env,
        timeout=args.compile_timeout,
    )
    normalized_sha = sha256_bytes(lockfile.read_bytes())
    target_still_empty = not workspace.target.exists()
    return {
        "copied_lockfile_sha256": copied_sha,
        "normalized_lockfile_sha256": normalized_sha,
        "normalization": result,
        "target_still_absent": target_still_empty,
    }


def test_command(cargo: str, target: TestTarget, engine: str = "c-abi") -> list[str]:
    return [
        cargo,
        *cargo_args(engine),
        *target.cargo_selector,
        target.exact_name,
        "--",
        "--exact",
        "--nocapture",
    ]


def test_count(result: dict[str, object]) -> int:
    return sum(int(count) for count in result["running_test_counts"])


def resolve_build_dirs(
    args: argparse.Namespace, selected: Sequence[Mutation]
) -> tuple[Path | None, bool]:
    hooks_needed = any(mutation.test.needs_hooks for mutation in selected)
    native_needed = args.engine == "sto" or hooks_needed or any(
        mutation.test.needs_native for mutation in selected
    )

    hook_value = args.hook_build_dir
    native_value = args.mako_build_dir
    if native_needed:
        hook_value = hook_value or os.environ.get("MAKO_CACHE_HOOK_BUILD_DIR")
        native_value = native_value or os.environ.get("MAKO_BUILD_DIR")

    if hook_value:
        chosen = Path(hook_value).expanduser().resolve()
        require_hooks = True
    elif native_value:
        chosen = Path(native_value).expanduser().resolve()
        require_hooks = False
    else:
        chosen = None
        require_hooks = False

    # Rust STO implements the observer hooks in Rust. Its Masstree archive
    # must be genuine, but need not enable the C++ transaction test hooks.
    if args.engine == "sto":
        require_hooks = hooks_needed
        if os.environ.get("MAKO_MTREE_NATIVE_INTEGRATION") != "1":
            raise HarnessFailure("Rust STO mutations require MAKO_MTREE_NATIVE_INTEGRATION=1")
        for name in ("MAKO_MTREE_NATIVE_LIB_DIRS", "MAKO_MTREE_NATIVE_LIBS"):
            if not os.environ.get(name):
                raise HarnessFailure(f"Rust STO mutations require {name}")

    if native_needed and chosen is None:
        raise HarnessFailure(
            "selected mutants require native Mako",
            details=(
                "pass --mako-build-dir PATH (or MAKO_BUILD_DIR); the full/default "
                "matrix includes the timestamp mutant and therefore requires "
                "--hook-build-dir PATH (or MAKO_CACHE_HOOK_BUILD_DIR)"
            ),
        )
    if hooks_needed and not require_hooks:
        raise HarnessFailure(
            "selected mutants require the hook-enabled native archive",
            details=(
                "pass --hook-build-dir PATH or set MAKO_CACHE_HOOK_BUILD_DIR; "
                "the directory must contain libmako.a built with "
                "MAKO_LOCAL_TEST_HOOKS=ON"
            ),
        )
    if chosen is not None:
        for required in (chosen / "libmako.a", chosen / "CMakeCache.txt"):
            if not required.is_file():
                raise HarnessFailure(
                    f"native build is incomplete: {required} is missing"
                )
    return chosen, require_hooks


def mutate_copy(workspace: TempWorkspace, mutation: Mutation) -> dict[str, str]:
    target = workspace.crate / mutation.relative_path
    source = target.read_text(encoding="utf-8")
    matches = source.count(mutation.anchor)
    if matches != 1:
        raise HarnessFailure(
            f"{mutation.name}: copied-source anchor count is {matches}, expected 1"
        )
    original_sha = sha256_text(source)
    mutated = source.replace(mutation.anchor, mutation.replacement, 1)
    if mutated == source:
        raise HarnessFailure(f"{mutation.name}: replacement did not change source")
    target.write_text(mutated, encoding="utf-8")
    observed = target.read_text(encoding="utf-8")
    if observed.count(mutation.anchor) != 0 or observed.count(mutation.replacement) != 1:
        raise HarnessFailure(
            f"{mutation.name}: mutation was not present exactly once after write"
        )
    return {
        "original_file_sha256": original_sha,
        "mutated_file_sha256": sha256_text(observed),
        "replacement_sha256": sha256_text(mutation.replacement),
    }


def native_profile(build: Path | None, engine: str, require_hooks: bool) -> dict[str, object]:
    return {
        "build_dir": str(build) if build else None,
        "commit_hooks_required": require_hooks,
        "hook_implementation": "rust" if engine == "sto" else "c++",
        "hook_archive_required": require_hooks and engine == "c-abi",
    }


def run_baseline(
    args: argparse.Namespace,
    native_build: Path | None,
    require_hooks: bool,
) -> dict[str, object]:
    workspace, rewrites = create_workspace(
        "baseline", args.keep_workdirs, args.resolved_temp_root, args.resolved_local_source
    )
    try:
        env = cargo_environment(
            workspace, native_build=native_build, require_hooks=require_hooks
        )
        toolchain = {}
        for name, command in (("rustc", [env.get("RUSTC", "rustc"), "--version", "--verbose"]),
                              ("cargo", [args.cargo, "--version", "--verbose"])):
            version = command_result(command, cwd=workspace.root, env=env,
                                     timeout=args.compile_timeout)
            if version["timed_out"] or version["returncode"] != 0:
                raise HarnessFailure(f"cannot identify baseline {name}", details=version)
            toolchain[name] = str(version["stdout_tail"]).strip()
        lock_setup = prepare_lockfile(args, workspace, env)
        if (
            lock_setup["normalization"]["timed_out"]
            or lock_setup["normalization"]["returncode"] != 0
            or not lock_setup["target_still_absent"]
        ):
            return {
                "status": "harness_error",
                "reason": "copied lockfile normalization failed or populated target",
                "workspace": str(workspace.root) if args.keep_workdirs else None,
                "path_rewrites": rewrites,
                "lock_setup": lock_setup,
            }
        compile_command = [args.cargo, *cargo_args(args.engine), "--no-run"]
        print(f"baseline compile: {command_display(compile_command)}", file=sys.stderr)
        compile_result = command_result(
            compile_command,
            cwd=workspace.root,
            env=env,
            timeout=args.compile_timeout,
        )
        if compile_result["timed_out"] or compile_result["returncode"] != 0:
            return {
                "status": "harness_error",
                "reason": "baseline did not compile",
                "workspace": str(workspace.root) if args.keep_workdirs else None,
                "path_rewrites": rewrites,
                "lock_setup": lock_setup,
                "compile": compile_result,
            }

        # Native cache instances share one process-wide cache-order namespace.
        # The ordinary CMake Rust gate serializes cache cases for the same
        # reason; preserve that contract in this isolated baseline too.
        test_command_line = [
            args.cargo,
            *cargo_args(args.engine),
            "--",
            "--test-threads=1",
        ]
        test_runs = []
        for iteration in range(args.baseline_runs):
            print(
                f"baseline tests {iteration + 1}/{args.baseline_runs}: "
                f"{command_display(test_command_line)}",
                file=sys.stderr,
                flush=True,
            )
            test_result = command_result(
                test_command_line,
                cwd=workspace.root,
                env=env,
                timeout=args.baseline_timeout,
            )
            test_runs.append(test_result)
            if test_result["timed_out"] or test_result["returncode"] != 0:
                break
        status = (
            "green"
            if not test_result["timed_out"] and test_result["returncode"] == 0
            else "harness_error"
        )
        return {
            "status": status,
            "toolchain": toolchain,
            "reason": None if status == "green" else "baseline tests were not green",
            "workspace": str(workspace.root) if args.keep_workdirs else None,
            "path_rewrites": rewrites,
            "lock_setup": lock_setup,
            "compile": compile_result,
            "tests": test_result,
            "test_runs": test_runs,
        }
    finally:
        workspace.close()


def run_mutation(
    args: argparse.Namespace,
    mutation: Mutation,
    native_build: Path | None,
    require_hooks: bool,
) -> dict[str, object]:
    workspace, rewrites = create_workspace(
        mutation.name, args.keep_workdirs, args.resolved_temp_root, args.resolved_local_source
    )
    base: dict[str, object] = {
        "name": mutation.name,
        "path": mutation.relative_path,
        "anchor_sha256": mutation.anchor_sha256,
        "expected_signature": mutation.test.failure_signature,
        "designated_test": mutation.test.exact_name,
        "breaks": mutation.breaks,
        "workspace": str(workspace.root) if args.keep_workdirs else None,
        "path_rewrites": rewrites,
    }
    try:
        base.update(mutate_copy(workspace, mutation))
        env = cargo_environment(
            workspace, native_build=native_build, require_hooks=require_hooks
        )
        lock_setup = prepare_lockfile(args, workspace, env)
        base["lock_setup"] = lock_setup
        if (
            lock_setup["normalization"]["timed_out"]
            or lock_setup["normalization"]["returncode"] != 0
            or not lock_setup["target_still_absent"]
        ):
            base.update(
                status="harness_error",
                reason="copied lockfile normalization failed or populated target",
            )
            return base
        compile_command = [
            args.cargo,
            *cargo_args(args.engine),
            *mutation.test.cargo_selector,
            "--no-run",
        ]
        print(f"{mutation.name}: compile", file=sys.stderr, flush=True)
        compile_result = command_result(
            compile_command,
            cwd=workspace.root,
            env=env,
            timeout=args.compile_timeout,
        )
        base["compile"] = compile_result
        if compile_result["timed_out"]:
            base.update(status="harness_error", reason="mutant compilation timed out")
            return base
        if compile_result["returncode"] != 0:
            base.update(
                status="harness_error",
                reason="mutant did not compile; compile failures do not count as kills",
            )
            return base

        command = test_command(args.cargo, mutation.test, args.engine)
        print(
            f"{mutation.name}: test {mutation.test.exact_name}",
            file=sys.stderr,
            flush=True,
        )
        result = command_result(
            command,
            cwd=workspace.root,
            env=env,
            timeout=args.test_timeout,
        )
        base["test"] = result
        if result["timed_out"]:
            base.update(
                status="harness_error",
                reason="designated test timed out; hangs do not count as kills",
            )
            return base

        executed = test_count(result)
        base["executed_test_count"] = executed
        if executed != 1:
            base.update(
                status="harness_error",
                reason=f"designated command executed {executed} tests, expected exactly 1",
            )
            return base
        if result["returncode"] == 0:
            base.update(
                status="survived",
                reason="designated test passed with the mutant present",
            )
            return base
        signature = mutation.test.failure_signature
        if signature not in result["failed_test_lines"]:
            base.update(
                status="harness_error",
                reason="test process failed without the designated failure signature",
            )
            return base
        base.update(
            status="killed",
            reason="designated exact test failed with the expected signature",
            observed_signature=signature,
        )
        return base
    except HarnessFailure as error:
        base.update(status="harness_error", reason=str(error), details=error.details)
        return base
    finally:
        workspace.close()


def mutation_summary(mutation: Mutation) -> dict[str, object]:
    return {
        "name": mutation.name,
        "path": mutation.relative_path,
        "anchor_sha256": mutation.anchor_sha256,
        "designated_test": mutation.test.exact_name,
        "needs_native": mutation.test.needs_native,
        "needs_hooks": mutation.test.needs_hooks,
        "breaks": mutation.breaks,
    }


def write_report(report: dict[str, object], destination: str | None) -> None:
    rendered = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if destination:
        path = Path(destination).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(rendered, encoding="utf-8")
    sys.stdout.write(rendered)


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("mutations", nargs="*", help="mutation names; default: all")
    result.add_argument("--list", action="store_true", help="list mutation contracts as JSON")
    result.add_argument(
        "--check",
        action="store_true",
        help="validate names, exact anchors, digests, and source integrity without Cargo",
    )
    result.add_argument("--cargo", default="cargo", help="Cargo executable")
    result.add_argument("--engine", choices=("c-abi", "sto"), default="c-abi",
                        help="engine for both the unmutated baseline and every mutant")
    result.add_argument(
        "--mako-build-dir",
        help="CMake tree containing libmako.a for native tests (or MAKO_BUILD_DIR)",
    )
    result.add_argument(
        "--hook-build-dir",
        help=(
            "CMake tree containing the MAKO_LOCAL_TEST_HOOKS=ON libmako.a; "
            "takes precedence over --mako-build-dir (or MAKO_CACHE_HOOK_BUILD_DIR)"
        ),
    )
    result.add_argument(
        "--mako-local-source-dir",
        help=(
            "use an existing native build's original mako-local crate path only "
            "after proving both Rust FFI crates, ABI headers, and verifier are "
            "byte-identical; native fingerprint verification remains mandatory"
        ),
    )
    result.add_argument("--compile-timeout", type=int, default=900)
    result.add_argument("--baseline-timeout", type=int, default=1200)
    result.add_argument("--baseline-runs", type=int, default=1,
                        help="repeat the full unmutated baseline; every run must pass")
    result.add_argument("--test-timeout", type=int, default=180)
    result.add_argument("--jobs", type=int, default=1,
                        help="independent mutant workspaces to compile/test concurrently; baseline runs first")
    result.add_argument(
        "--temp-root",
        help=(
            "parent for isolated workspaces/targets; defaults to "
            "MAKO_CACHE_MUTATION_TEMP_ROOT or the user's cache directory"
        ),
    )
    result.add_argument(
        "--keep-workdirs",
        action="store_true",
        help="retain isolated workspaces for debugging and report their paths",
    )
    result.add_argument(
        "--report",
        help="also write the JSON report to this path; JSON is always printed to stdout",
    )
    return result


def select_mutations(names: Iterable[str]) -> list[Mutation]:
    wanted = list(names)
    by_name = {mutation.name: mutation for mutation in MUTATIONS}
    unknown = sorted(set(wanted) - set(by_name))
    if unknown:
        raise HarnessFailure("unknown mutation name(s)", details=unknown)
    return [by_name[name] for name in wanted] if wanted else list(MUTATIONS)


def resolve_temp_root(value: str | None) -> Path:
    configured = value or os.environ.get("MAKO_CACHE_MUTATION_TEMP_ROOT")
    if configured:
        return Path(configured).expanduser().resolve()
    cache_home = os.environ.get("XDG_CACHE_HOME")
    base = Path(cache_home).expanduser() if cache_home else Path.home() / ".cache"
    return (base / "mako-cache-mutations").resolve()


def main(argv: Sequence[str] | None = None) -> int:
    args = parser().parse_args(argv)
    args.resolved_temp_root = resolve_temp_root(args.temp_root)
    started_wall = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    started = time.monotonic()
    before = source_hashes()
    report: dict[str, object] = {
        "schema": "mako-cache-phase1f-mutations-v1",
        "started_utc": started_wall,
        "original_crate": str(ORIGINAL_CRATE),
        "temp_root": str(args.resolved_temp_root),
        "scope": "applied-to-Rocks; asynchronous and not a Rocks WAL durability claim",
        "engine": args.engine,
        "toolchain_pin_sha256": sha256_bytes(ORIGINAL_TOOLCHAIN.read_bytes()),
        "rustup_toolchain_override": os.environ.get("RUSTUP_TOOLCHAIN"),
        "dependency_source_integrity": {"file_sha256": dependency_hashes()},
    }
    exit_code = 2
    try:
        if args.jobs < 1:
            raise HarnessFailure("--jobs must be positive")
        if args.baseline_runs < 1:
            raise HarnessFailure("--baseline-runs must be positive")
        selected = select_mutations(args.mutations)
        report["selected"] = [mutation.name for mutation in selected]
        if args.list:
            report["status"] = "listed"
            report["mutations"] = [mutation_summary(mutation) for mutation in selected]
            exit_code = 0
            return finish(report, before, started, args.report, exit_code)

        validations = validate_definitions(selected)
        report["anchor_validation"] = validations
        args.resolved_local_source, wrapper_proof = verify_wrapper_override(args.mako_local_source_dir)
        report["native_wrapper_source"] = wrapper_proof
        if args.check:
            # Exercise the copy/manifest rewrite path too.  This catches a new
            # relative dependency (for example mako-history) before a long run.
            workspace, rewrites = create_workspace(
                "check", False, args.resolved_temp_root, args.resolved_local_source
            )
            try:
                report["path_rewrites"] = rewrites
                report["copied_lockfile_sha256"] = sha256_bytes(
                    (workspace.root / "Cargo.lock").read_bytes()
                )
                report["empty_target_confirmed"] = not workspace.target.exists()
            finally:
                workspace.close()
            report["status"] = "checked"
            exit_code = 0
            return finish(report, before, started, args.report, exit_code)

        native_build, require_hooks = resolve_build_dirs(args, selected)
        report["native_profile"] = native_profile(native_build, args.engine, require_hooks)

        baseline = run_baseline(args, native_build, require_hooks)
        report["baseline"] = baseline
        if baseline["status"] != "green":
            report["status"] = "harness_error"
            report["reason"] = "unmutated baseline must compile and pass first"
            exit_code = 2
            return finish(report, before, started, args.report, exit_code)

        completed_results = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as workers:
            futures = {
                workers.submit(run_mutation, args, mutation, native_build, require_hooks): mutation
                for mutation in selected
            }
            for future in concurrent.futures.as_completed(futures):
                mutation = futures[future]
                result = future.result()
                completed_results[mutation.name] = result
                print(f"{mutation.name}: {result['status']}", file=sys.stderr, flush=True)
        results = [completed_results[mutation.name] for mutation in selected]
        report["mutations"] = results
        killed = sum(result["status"] == "killed" for result in results)
        survived = sum(result["status"] == "survived" for result in results)
        harness_errors = sum(result["status"] == "harness_error" for result in results)
        report["score"] = {
            "killed": killed,
            "total": len(results),
            "survived": survived,
            "harness_errors": harness_errors,
        }
        if harness_errors:
            report["status"] = "harness_error"
            exit_code = 2
        elif survived:
            report["status"] = "mutation_survived"
            exit_code = 1
        else:
            report["status"] = "all_killed"
            exit_code = 0
        return finish(report, before, started, args.report, exit_code)
    except HarnessFailure as error:
        report["status"] = "harness_error"
        report["reason"] = str(error)
        report["details"] = error.details
        return finish(report, before, started, args.report, 2)


def finish(
    report: dict[str, object],
    before: dict[str, str],
    started: float,
    destination: str | None,
    intended_exit: int,
) -> int:
    after = source_hashes()
    changed = sorted(
        path
        for path in set(before) | set(after)
        if before.get(path) != after.get(path)
    )
    integrity = {
        "file_count": len(before),
        "before_tree_sha256": tree_digest(before),
        "after_tree_sha256": tree_digest(after),
        "unchanged": not changed,
        "changed_paths": changed,
        "file_sha256": before,
    }
    report["source_integrity"] = integrity
    dependencies = report["dependency_source_integrity"]
    dependencies_before = dependencies["file_sha256"]
    dependencies_after = dependency_hashes()
    dependencies_changed = sorted(
        path for path in set(dependencies_before) | set(dependencies_after)
        if dependencies_before.get(path) != dependencies_after.get(path)
    )
    dependencies.update(
        file_count=len(dependencies_before),
        before_tree_sha256=tree_digest(dependencies_before),
        after_tree_sha256=tree_digest(dependencies_after),
        unchanged=not dependencies_changed,
        changed_paths=dependencies_changed,
    )
    if dependencies_changed:
        report["status"] = "harness_error"
        report["reason"] = "path-dependency sources changed during the run"
        intended_exit = 2
    wrapper_proof = report.get("native_wrapper_source")
    if wrapper_proof:
        try:
            original_now = wrapper_hashes(Path(wrapper_proof["original"]))
            selected_now = wrapper_hashes(Path(wrapper_proof["selected"]))
            wrapper_unchanged = original_now == selected_now == wrapper_proof["file_sha256"]
        except (HarnessFailure, OSError) as error:
            wrapper_unchanged = False
            wrapper_proof["integrity_error"] = str(error)
        wrapper_proof["unchanged_after_run"] = wrapper_unchanged
        if not wrapper_unchanged:
            report["status"] = "harness_error"
            report["reason"] = "native wrapper sources changed during the run"
            intended_exit = 2
    report["elapsed_seconds"] = round(time.monotonic() - started, 3)
    if changed:
        report["status"] = "harness_error"
        report["reason"] = "original mako-cache source changed during the run"
        intended_exit = 2
    write_report(report, destination)
    return intended_exit


if __name__ == "__main__":
    raise SystemExit(main())
