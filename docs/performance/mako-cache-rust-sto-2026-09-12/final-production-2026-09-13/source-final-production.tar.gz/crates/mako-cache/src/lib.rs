//! Transactional STO write-back cache over RocksDB.
//!
//! The selected engine is the authoritative live state while this process
//! runs. Feature `engine-c-abi` (default) uses C++ STO/MassTrans; `engine-sto`
//! uses Rust STO over the native C++ Masstree index. Select exactly one engine,
//! using `default-features = false` when selecting `engine-sto`.
//!
//! Before commit, the engine sizes and seals its canonical final write set
//! while the cache claims bounded capacity in the current worker's SPSC
//! writeback lane. The engine coordinates Mako timestamp assignment with
//! final validation while holding the complete write set's locks. A failed
//! validation may leave a timestamp gap but never a physical log record. The
//! engine seals the record or its owned deferred one-put payload in lane-owned
//! storage before installing the writes. A successful worker
//! acknowledges as soon as its own record is Ready, without waiting for another
//! lane. The background writer polls lanes in round-robin order and applies a
//! bounded contiguous prefix from one lane in each atomic RocksDB
//! `WriteBatch`. Because physical batch order may differ from serialization
//! order, a shared coordinator uses Mako timestamps to prevent an older record
//! from replacing a newer materialized value. Applied log records remain
//! available for recovery until checkpoint-backed, age-based GC reclaims
//! them; the default retention is five minutes.
//!
//! [`Cache::wait_applied`] and [`Cache::close`] drain acknowledged work into
//! RocksDB, but neither operation adds a separate WAL flush or disk sync. The
//! default batch mode uses `sync=false`; the applied watermark is process-local
//! progress, not a durability promise.
//! This first slice exposes one logical application table. Queue occupancy and
//! individual record size are bounded; transactions may contain many keys.
//!
//! ```no_run
//! # fn main() -> Result<(), mako_cache::Error> {
//! let db = mako_cache::Db::open("/tmp/mako-cache", mako_cache::Options::default())?;
//! let mut tx = db.transaction()?;
//! tx.put(b"alice", b"10")?;
//! tx.put(b"bob", b"20")?;
//! tx.commit()?; // visible and queued, not necessarily in Rocks yet
//! db.wait_applied()?;
//! db.close()?;
//! # Ok(())
//! # }
//! ```

#![deny(unsafe_code)]
#![deny(unsafe_op_in_unsafe_fn)]
#![warn(missing_docs)]

use std::cell::Cell;
use std::fmt;
use std::marker::PhantomData;
use std::num::{NonZeroU32, NonZeroU64};
use std::path::Path;
use std::rc::Rc;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Duration;

use mako_engine::{CommitDisposition, LocalDb};
use mrx_core::{BlobError, Blobs};
use mrx_rocks::RocksBlobs;

mod checkpoint;
#[cfg(test)]
mod failpoint;
mod recovery;
// Reviewed native-record ownership seam. Keep unsafe code denied everywhere
// else in the crate so future fast-path work cannot silently broaden it.
#[allow(unsafe_code)]
mod record;
mod runtime;
/// Backend injection and structural probes used only by validation binaries.
#[cfg(feature = "test-support")]
#[doc(hidden)]
pub mod test_support;
// Reviewed fixed-address queue/arena implementation.
#[allow(unsafe_code)]
mod writeback;
mod writeback_set;

#[cfg(all(test, have_mako, have_rocksdb, target_family = "unix"))]
mod crash_tests;

#[cfg(all(test, have_mako))]
mod application_history_tests;

#[cfg(all(test, have_mako))]
mod milestone1_acceptance_tests;

pub use mako_engine::{CommitRecordChecksum as RecordChecksum, Error as LocalError, MakoTimestamp};

/// Name of the local transaction engine this cache was compiled against.
///
/// Validation binaries record it so a database written by one engine build
/// can be reopened by the other and the two builds can be told apart.
pub fn engine_name() -> &'static str {
    <mako_engine::Engine as mako_engine::LocalEngine>::NAME
}
pub use mrx_rocks::Durability;
pub use record::{CommitSeq, RecordError};
pub use writeback::{
    AppliedWatermark, ApplyError, ConfigError as WritebackConfigError, LogGcStatus, ReserveError,
    ResolveError, WritebackConfig,
};

#[cfg(not(test))]
use record::DEFAULT_TABLE_ID;
#[cfg(test)]
use record::{
    classify_backend_key, split_log_sequence, BackendKey, CommitRecord, Mutation, DEFAULT_TABLE_ID,
};
use recovery::recover;
use runtime::{Runtime, RuntimeError};
use writeback::Writeback;
use writeback_set::WritebackSet;

const DEFAULT_TABLE_NAME: &[u8] = b"mako-cache/default";

const COMMIT_FENCE_SPINS: usize = 64;
static NEXT_COMMIT_FENCE_THREAD_SLOT: AtomicUsize = AtomicUsize::new(0);

thread_local! {
    /// Process-lifetime slot paired with native's process-lifetime worker.
    ///
    /// A slot number need not equal STO's worker ID. Cache transaction begin
    /// attaches to STO before allocating this slot. Neither allocator recycles
    /// a departed OS thread's slot.
    static COMMIT_FENCE_THREAD_SLOT: Cell<usize> = const { Cell::new(usize::MAX) };
}

#[repr(align(64))]
struct CommitWriterSlot {
    /// Owner-written generations: even is idle and the following odd value is
    /// one active outcome. A reader waits for one exact observed odd value, so
    /// a later writer generation cannot extend that wait indefinitely.
    generation: AtomicU64,
}

impl CommitWriterSlot {
    const fn new() -> Self {
        Self {
            generation: AtomicU64::new(0),
        }
    }

    #[inline(always)]
    fn begin(&self, slot: usize) -> u64 {
        let idle = self.generation.load(Ordering::Relaxed);
        assert_eq!(
            idle & 1,
            0,
            "one native worker cannot overlap two cache commit outcomes: slot={slot}, generation={idle:#018x}"
        );
        let active = idle.wrapping_add(1);
        self.generation.store(active, Ordering::Release);
        active
    }

    #[inline(always)]
    fn drain_observed(&self, observed: u64, spins: &mut usize) {
        if observed & 1 == 0 {
            return;
        }
        // Equality can alias a later active generation only after 2^64 owner
        // transitions. Exact wrap may conservatively extend this wait through
        // one later outcome, but it cannot hide the already-resolved prefix.
        while self.generation.load(Ordering::Acquire) == observed {
            commit_fence_backoff(spins);
        }
    }
}

const _: () = assert!(std::mem::size_of::<CommitWriterSlot>() == 64);

/// An asymmetric outcome fence for writers and read-only commits.
///
/// Each attached writer modifies only its own cache line before entering the
/// native packed cache-order protocol. A read-only commit marks a cut in that
/// atomic modification order, then guarantees that every writer before it has
/// drained. A scan may also conservatively wait for one observed post-cut
/// generation. Later writers may proceed because STO orders them after the
/// read-only transaction or rejects read-only validation on a conflicting
/// lock, version, or predicate.
struct CommitFence {
    writers: Box<[CommitWriterSlot]>,
}

impl CommitFence {
    fn new() -> Self {
        let writers = (0..mako_engine::MAX_WORKERS)
            .map(|_| CommitWriterSlot::new())
            .collect::<Vec<_>>()
            .into_boxed_slice();
        Self { writers }
    }

    #[inline(always)]
    fn try_current_thread_slot() -> Result<usize, LocalError> {
        COMMIT_FENCE_THREAD_SLOT.with(|thread_slot| {
            let current = thread_slot.get();
            if current != usize::MAX {
                return Ok(current);
            }
            let allocated = NEXT_COMMIT_FENCE_THREAD_SLOT
                .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |next| {
                    (next < mako_engine::MAX_WORKERS).then_some(next + 1)
                })
                .map_err(|_| LocalError::ThreadLimit)?;
            thread_slot.set(allocated);
            Ok(allocated)
        })
    }

    #[inline(always)]
    fn current_thread_slot() -> usize {
        Self::try_current_thread_slot()
            .expect("an attached cache transaction must own a commit-fence slot")
    }

    #[inline(always)]
    fn enter_writer(&self) -> CommitWriterGuard<'_> {
        self.enter_writer_slot(Self::current_thread_slot())
    }

    #[inline(always)]
    fn enter_writer_slot(&self, slot: usize) -> CommitWriterGuard<'_> {
        let writer = self
            .writers
            .get(slot)
            .expect("commit-fence writer slot is in range");
        let active_generation = writer.begin(slot);
        CommitWriterGuard {
            slot,
            writer,
            active_generation,
        }
    }

    #[inline]
    fn read_only_scan_bound(&self, order_validation_prefix: impl FnOnce()) -> usize {
        order_validation_prefix();
        // A prefix writer registered its slot before its packed Release RMW.
        // The cut acquires that publication or its release sequence. Loading
        // the monotone registration counter AFTER that cut therefore includes
        // every prefix writer, even though registration itself was Relaxed.
        // An Acquire load before the cut would not establish this guarantee.
        // Slots are never reused and this counter never decreases or resets.
        NEXT_COMMIT_FENCE_THREAD_SLOT.load(Ordering::Acquire)
    }

    fn close_for_read_only(&self, order_validation_prefix: impl FnOnce()) {
        // Each reader owns its cut and its observed generations. Readers
        // neither change a writer slot nor consume another reader's result.
        // Their Acquire RMWs remain members of the packed word's release
        // sequence, so overlapping readers preserve the same prefix proof.
        // A writer's odd-generation Release publication precedes its packed
        // assignment or general-lock Release RMW. The callback's Acquire RMW
        // reads that modification or a later member of its release sequence.
        // Each following Acquire load must see a prefix writer's active
        // generation, or its later Release clear after the outcome is
        // represented in write-back.
        //
        // A writer can publish its generation before this cut but enter packed
        // order after it. Native acquires that writer's complete write set
        // first, but cannot install until after ordering and validation.
        // STO validation therefore either rejects this read-only transaction
        // on a conflicting lock/predicate, or admits the reader-before-writer
        // serialization. Missing that post-cut generation is safe.
        let registered = self.read_only_scan_bound(order_validation_prefix);

        let mut spins = 0;
        for writer in &self.writers[..registered] {
            let observed = writer.generation.load(Ordering::Acquire);
            writer.drain_observed(observed, &mut spins);
        }
    }
}

#[inline(always)]
fn commit_fence_backoff(spins: &mut usize) {
    if *spins < COMMIT_FENCE_SPINS {
        *spins += 1;
        std::hint::spin_loop();
    } else {
        std::thread::yield_now();
    }
}

struct CommitWriterGuard<'a> {
    slot: usize,
    writer: &'a CommitWriterSlot,
    active_generation: u64,
}

impl CommitWriterGuard<'_> {
    #[inline(always)]
    fn slot(&self) -> usize {
        self.slot
    }
}

impl Drop for CommitWriterGuard<'_> {
    #[inline(always)]
    fn drop(&mut self) {
        // The closer's Acquire scan carries all native outcome and
        // queue-resolution effects which precede this Release clear.
        debug_assert_eq!(
            self.writer.generation.load(Ordering::Relaxed),
            self.active_generation
        );
        self.writer
            .generation
            .store(self.active_generation.wrapping_add(1), Ordering::Release);
    }
}

/// Foreground transaction concurrency accepted by one cache instance.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub enum ForegroundMode {
    /// Transactions may begin and commit concurrently on many worker threads.
    #[default]
    Concurrent,
    /// Transactions use one explicit, thread-affine foreground lease.
    ///
    /// The lease makes foreground calls sequential without a per-transaction
    /// ownership check. This lets the queue use its single-producer protocol;
    /// [`Cache::transaction`] is deliberately disabled and callers must use
    /// [`Cache::single_producer`] instead.
    SingleProducer,
}

/// Cache-specific behavior independent of the concrete backend.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct CacheOptions {
    /// Bounded transaction-log and retry settings.
    pub writeback: WritebackConfig,
    /// Retain applied transaction logs until their HLC physical time is older
    /// than Unix time minus this duration. Defaults to five minutes. Row and
    /// deletion timestamps remain after log expiration. Zero expires records
    /// on the next eligible GC sweep; it does not disable WAL or logging.
    pub log_retention: Duration,
    /// Monotonic interval between background log-GC sweeps. Must be nonzero.
    /// Each sweep interleaves bounded deletion batches with normal writeback.
    pub gc_interval: Duration,
    /// Foreground transaction concurrency profile.
    pub foreground_mode: ForegroundMode,
    /// Integrity mode for newly produced cache-log records.
    ///
    /// [`RecordChecksum::Crc32c`] is the corruption-detecting default. The
    /// explicitly selected [`RecordChecksum::None`] format is self-describing
    /// and remains replay-compatible, but deliberately trades payload
    /// corruption detection for foreground commit latency.
    pub record_checksum: RecordChecksum,
    /// Logical CPU on which to run the cache's write-back consumer.
    ///
    /// `None` inherits the process affinity. A selected CPU pins only the
    /// `mako-writeback` thread; RocksDB's own internal threads are outside this
    /// setting. Explicit affinity is currently supported on Linux, where an
    /// invalid or disallowed CPU makes cache startup fail.
    pub writeback_cpu: Option<usize>,
    /// Elapsed backend-call time after which [`Cache::status`] reports
    /// [`CacheHealth::Degraded`].
    ///
    /// The status still exposes every in-progress call and its monotonic age,
    /// so a deployment may enforce a stricter external threshold. This timer
    /// does not cancel RocksDB and does not change shutdown semantics.
    pub backend_stall_threshold: Duration,
    /// Reject startup unless the native engine advertises conventional
    /// read-your-writes behavior.
    ///
    /// Point and transactional-scan read-your-writes are part of the default
    /// cache profile. Set this to `false` only when deliberately opening
    /// against a legacy native build.
    pub require_read_my_writes: bool,
    /// Isolation profile required from the native transaction engine.
    ///
    /// The production default is committed-transaction strict
    /// serializability. Select [`Isolation::Opaque`] only when applications
    /// also require aborted and in-flight transactions to observe a
    /// consistent snapshot; startup then rejects a non-opaque native build.
    pub isolation: Isolation,
}

/// Native transaction isolation required by the cache deployment.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub enum Isolation {
    /// Committed transactions are strictly serializable.
    #[default]
    StrictSerializable,
    /// Every transaction, including aborted and in-flight work, observes a
    /// consistent snapshot.
    Opaque,
}

impl Default for CacheOptions {
    fn default() -> Self {
        Self {
            writeback: WritebackConfig::default(),
            log_retention: Duration::from_secs(300),
            gc_interval: Duration::from_secs(10),
            foreground_mode: ForegroundMode::Concurrent,
            record_checksum: RecordChecksum::Crc32c,
            writeback_cpu: None,
            backend_stall_threshold: Duration::from_secs(30),
            require_read_my_writes: true,
            isolation: Isolation::StrictSerializable,
        }
    }
}

/// Options for the concrete RocksDB-backed [`Db`].
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Options {
    /// RocksDB write mode used for each atomic batch.
    ///
    /// The default is [`Durability::Wal`], which keeps the WAL enabled with
    /// per-write synchronization disabled. The cache never separately flushes
    /// or syncs RocksDB.
    pub durability: Durability,
    /// Cache and transaction-log settings.
    pub cache: CacheOptions,
}

impl Default for Options {
    fn default() -> Self {
        Self {
            durability: Durability::Wal,
            cache: CacheOptions::default(),
        }
    }
}

/// Operational health of one cache instance.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CacheHealth {
    /// The writer is running with no active retry, fail-stop condition, or
    /// backend call older than the configured stall threshold.
    Healthy,
    /// The background writer is running with an active retry or backend stall.
    ///
    /// Foreground commits may still acknowledge into the bounded volatile
    /// queue. Capacity backpressure remains the admission limit while the
    /// writer retries.
    Degraded,
    /// The background writer stopped, or write-back reached a permanent
    /// fail-stop condition.
    Unhealthy,
}

/// Stage which produced a retained write-back diagnostic.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum WritebackFailureKind {
    /// The backend-application pipeline returned an error.
    ///
    /// In a panic-unwind build this also includes backend panics, which the
    /// coordinator converts into a normal error while retaining the exact
    /// batch for retry. The workspace release profile uses `panic = "abort"`;
    /// a panic in that profile terminates the process instead.
    Backend,
    /// A queued native record could not be materialized for replay.
    Record,
    /// In a panic-unwind build, the outer background runtime loop caught a
    /// panic outside the backend panic boundary. The workspace release profile
    /// aborts the process instead of producing this diagnostic.
    RuntimeLoopPanic,
}

/// Most recently observed write-back failure.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WritebackFailure {
    /// Failure stage.
    pub kind: WritebackFailureKind,
    /// First physical cache sequence involved, when one is known.
    pub sequence: Option<CommitSeq>,
    /// Owned diagnostic text retained after the original error is returned.
    pub message: String,
}

/// Backend batch currently inside `Blobs::write_batch`.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct BackendWriteInProgress {
    /// First physical cache sequence in the atomic batch.
    pub sequence: CommitSeq,
    /// Monotonic time elapsed since the backend call began.
    pub elapsed: Duration,
}

/// Point-in-time cache health and progress counters.
///
/// Coordinator retry and failure fields are one coherent snapshot. Runtime
/// liveness and queue progress are sampled separately and may move while this
/// value is being assembled. Applied progress remains process-local and does
/// not mean that RocksDB synced its WAL. Coordinator failure counters cover
/// both the dedicated `mako-writeback` thread and caller-driven
/// [`Cache::wait_applied`] attempts.
///
/// Timestamp-clock RDTSCP fallback state is not yet available through the
/// native C ABI. Add that native diagnostic before using clock-source changes
/// in readiness policy.
#[derive(Clone, Debug)]
#[must_use = "cache health snapshots should be inspected or exported"]
pub struct CacheStatus {
    /// Overall operational classification for this snapshot.
    pub health: CacheHealth,
    /// Whether the engine runtime can still admit transactions.
    ///
    /// Rust STO reports both core-runtime failure after uncertain cleanup and
    /// shared native-directory poison, even before a point operation maps it
    /// into this database's core runtime. C++ STO quarantines individual
    /// workers instead, so its runtime stays healthy.
    /// Reading this field neither attaches nor quarantines the calling worker.
    pub engine_runtime_healthy: bool,
    /// Whether the dedicated background writer has not stopped or unwound.
    pub background_writer_running: bool,
    /// Backend-application failures observed by any consumer since startup.
    pub backend_failures: u64,
    /// Replay-materialization failures observed by any consumer since startup.
    ///
    /// Allocation failures are retryable. Structural record failures also
    /// appear in [`Self::writeback_error`] and make the cache unhealthy.
    pub record_failures: u64,
    /// Panics caught by the outer dedicated-writer loop since startup in a
    /// panic-unwind build.
    ///
    /// Backend panics are then converted into ordinary backend failures inside
    /// the coordinator and increment [`Self::backend_failures`] instead. The
    /// workspace release profile uses `panic = "abort"`, so either kind of
    /// panic terminates the process and cannot increment these counters.
    pub runtime_loop_panics: u64,
    /// Consecutive failed dedicated-writer attempts. Panic-unwind builds also
    /// count caught panics; the workspace release profile aborts on panic.
    ///
    /// This returns to zero after the writer applies a batch or observes an
    /// empty queue.
    pub consecutive_background_failures: u64,
    /// First physical sequence of the exact batch that must retry before
    /// another lane may apply.
    pub pending_backend_retry: Option<CommitSeq>,
    /// Physical sequences with a retryable failure that has not yet been
    /// followed by successful application of that sequence.
    ///
    /// The pending exact-retry sequence appears here too. Allocation and
    /// record-materialization failures can appear here without requiring the
    /// stricter cross-lane barrier represented by
    /// [`Self::pending_backend_retry`].
    pub active_retryable_failures: Vec<CommitSeq>,
    /// Backend call currently in progress, including its monotonic age.
    pub backend_write_in_progress: Option<BackendWriteInProgress>,
    /// Threshold used to classify a long in-progress backend call as degraded.
    pub backend_stall_threshold: Duration,
    /// Most recent coordinator or background-runtime failure.
    ///
    /// This remains available after a later successful retry.
    pub last_failure: Option<WritebackFailure>,
    /// Permanent write-back failure, if this cache has latched one.
    pub writeback_error: Option<ApplyError>,
    /// Current process-local backend application watermark.
    pub applied_watermark: AppliedWatermark,
    /// Cache transactions acknowledged to foreground callers.
    pub acknowledged_transactions: u64,
    /// Bound prepared, ready, or currently applying queue slots across lanes.
    ///
    /// Detached pre-commit capacity reservations are not included.
    pub queued_transactions: usize,
    /// Retained application-log history, GC progress, and GC backend errors.
    /// Reclaimed counts do not reduce the transaction application watermark.
    pub log_gc: LogGcStatus,
    /// Process-wide native workers quarantined after uncertain cleanup.
    ///
    /// This count is monotonic and can include workers outside this cache. It
    /// is informational and does not affect [`Self::health`]. A fixed-worker
    /// pool reports its own usable worker count separately.
    pub quarantined_workers: u64,
}

impl CacheStatus {
    /// Whether this snapshot has no active degradation or fail-stop signal.
    pub const fn is_healthy(&self) -> bool {
        matches!(self.health, CacheHealth::Healthy)
    }
}

/// Anything that can go wrong opening or using the transaction cache.
#[derive(Debug)]
pub enum Error {
    /// The native Silo/MassTrans boundary failed.
    Native(LocalError),
    /// The backend failed outside the asynchronous application path.
    Backend(BlobError),
    /// A backend transaction record was malformed or too large.
    Record(RecordError),
    /// Write-back construction options were invalid.
    WritebackConfig(WritebackConfigError),
    /// A complete pre-commit reservation could not be made.
    Reserve(ReserveError),
    /// A bound write-back reservation could not be resolved safely.
    ///
    /// In particular, a transaction that is known committed is retained and
    /// left unacknowledged when this cache has already observed an unknown
    /// post-bind outcome, including one in another worker lane.
    Resolve(ResolveError),
    /// An application barrier could not cover its acknowledged snapshot.
    Apply(ApplyError),
    /// Starting the background writer failed.
    RuntimeStart(std::io::Error),
    /// Stopping or draining the background writer failed.
    Runtime(RuntimeError),
    /// The runtime-handle mutex was poisoned.
    RuntimeLockPoisoned,
    /// This cache requires transactions to use its explicit single-producer
    /// lease instead of the concurrent foreground entry point.
    SingleProducerHandleRequired,
    /// A single-producer lease was requested for a concurrent cache.
    SingleProducerModeDisabled,
    /// Another live single-producer lease already owns the foreground path.
    SingleProducerAlreadyClaimed,
    /// Rust could not reserve owned transaction or recovery storage.
    AllocationFailed,
    /// The selected native feature profile is unavailable.
    MissingReadMyWrites,
    /// The deployment requires opacity but the native engine was built
    /// without it.
    MissingOpacity,
    /// The RocksDB contains a key outside this cache's tagged format.
    ForeignBackendKey,
    /// Persisted cache state uses an incompatible layout. Rebuild it in a new
    /// database; opening never converts or deletes existing data implicitly.
    RebuildRequired,
    /// Log retention or the GC scheduling interval cannot be represented, or
    /// the interval is zero.
    InvalidGcOptions,
    /// GC recovery requires the RocksDB WAL to remain enabled.
    WalRequired,
    /// A backend record or data key names a table unsupported by this slice.
    UnsupportedTable(u64),
    /// A backend log record and its materialized RocksDB data disagree.
    BackendStateMismatch,
    /// Recovery replay produced a result impossible for the retained history.
    RecoveryDiverged,
    /// Native installation succeeded, but terminal handle cleanup failed.
    ///
    /// The transaction is visible and its record has already been published.
    CommittedButCleanupFailed {
        /// Cache commit sequence that remains covered by write-back.
        sequence: CommitSeq,
        /// Native cleanup failure.
        source: LocalError,
    },
    /// Native definitely aborted after consuming a lane-local cache sequence,
    /// but rejected before it could produce a replayable record.
    ///
    /// Visibility is not ambiguous, so callers may retry the logical
    /// transaction. The consumed ordering slot is nevertheless permanently
    /// pinned and this cache instance cannot admit later work.
    BoundRecordUnwritten {
        /// Pinned cache commit sequence.
        sequence: CommitSeq,
        /// Definite pre-install native abort reason.
        abort: LocalError,
        /// A separate terminal-handle cleanup failure, if one occurred.
        cleanup: Option<LocalError>,
    },
    /// Native commit returned an outcome that cannot safely be called abort.
    ///
    /// The corresponding lane slot is permanently pinned. Cache-wide fail-stop
    /// rejects later commits and application barriers rather than risk skipping
    /// a possibly visible transaction.
    UnknownCommitOutcome {
        /// Pinned cache commit sequence.
        sequence: CommitSeq,
        /// Native commit failure whose visibility is ambiguous.
        source: LocalError,
        /// A separate terminal-handle cleanup failure, if one occurred.
        cleanup: Option<LocalError>,
    },
    /// A definitely aborted transaction also failed terminal handle cleanup.
    AbortCleanupFailed {
        /// Definite native abort reason, normally an OCC conflict.
        abort: LocalError,
        /// Cleanup failure.
        cleanup: LocalError,
    },
}

impl Error {
    /// Whether this error is a normal optimistic-concurrency conflict.
    pub fn is_conflict(&self) -> bool {
        matches!(self, Self::Native(LocalError::Conflict))
    }
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Native(error) => write!(f, "{error}"),
            Self::Backend(error) => write!(f, "{error}"),
            Self::Record(error) => write!(f, "{error}"),
            Self::WritebackConfig(error) => write!(f, "{error}"),
            Self::Reserve(error) => write!(f, "{error}"),
            Self::Resolve(error) => write!(f, "{error}"),
            Self::Apply(error) => write!(f, "{error}"),
            Self::RuntimeStart(error) => write!(f, "cannot start write-back worker: {error}"),
            Self::Runtime(error) => write!(f, "{error}"),
            Self::RuntimeLockPoisoned => write!(f, "the cache runtime lock is poisoned"),
            Self::SingleProducerHandleRequired => write!(
                f,
                "this cache requires transactions through its single-producer lease"
            ),
            Self::SingleProducerModeDisabled => {
                write!(
                    f,
                    "this cache was opened for concurrent foreground transactions"
                )
            }
            Self::SingleProducerAlreadyClaimed => {
                write!(f, "this cache already has a live single-producer lease")
            }
            Self::AllocationFailed => write!(f, "could not allocate owned cache state"),
            Self::MissingReadMyWrites => {
                write!(
                    f,
                    "the native engine does not provide required read-your-writes"
                )
            }
            Self::MissingOpacity => write!(
                f,
                "the cache requires opacity, but the native engine provides only strict serializability"
            ),
            Self::ForeignBackendKey => write!(
                f,
                "RocksDB contains a key outside the mako-cache tagged format"
            ),
            Self::RebuildRequired => write!(f, "cache layout is incompatible; rebuild in a new database"),
            Self::InvalidGcOptions => write!(f, "invalid log retention or GC interval"),
            Self::WalRequired => write!(f, "log GC requires RocksDB WAL; use Wal or Sync durability"),
            Self::UnsupportedTable(table) => {
                write!(f, "backend state names unsupported table {table}")
            }
            Self::BackendStateMismatch => {
                write!(f, "backend transaction log and materialized data disagree")
            }
            Self::RecoveryDiverged => write!(f, "native replay diverged from backend history"),
            Self::CommittedButCleanupFailed { sequence, source } => write!(
                f,
                "transaction {} committed and was queued, but native cleanup failed: {source}",
                sequence.get()
            ),
            Self::BoundRecordUnwritten {
                sequence,
                abort,
                cleanup,
            } => {
                write!(
                    f,
                    "transaction {} definitely aborted after binding, but its unwritten ordering slot pins write-back: {abort}",
                    sequence.get()
                )?;
                if let Some(cleanup) = cleanup {
                    write!(f, "; cleanup also failed: {cleanup}")?;
                }
                Ok(())
            }
            Self::UnknownCommitOutcome {
                sequence,
                source,
                cleanup,
            } => {
                write!(
                    f,
                    "transaction {} has unknown visibility and pins write-back: {source}",
                    sequence.get()
                )?;
                if let Some(cleanup) = cleanup {
                    write!(f, "; cleanup also failed: {cleanup}")?;
                }
                Ok(())
            }
            Self::AbortCleanupFailed { abort, cleanup } => write!(
                f,
                "transaction definitely aborted ({abort}), but cleanup failed: {cleanup}"
            ),
        }
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Native(error) => Some(error),
            Self::Backend(error) => Some(error),
            Self::Record(error) => Some(error),
            Self::WritebackConfig(error) => Some(error),
            Self::Reserve(error) => Some(error),
            Self::Resolve(error) => Some(error),
            Self::Apply(error) => Some(error),
            Self::RuntimeStart(error) => Some(error),
            Self::Runtime(error) => Some(error),
            Self::CommittedButCleanupFailed { source, .. } => Some(source),
            Self::BoundRecordUnwritten { abort, .. } => Some(abort),
            Self::UnknownCommitOutcome { source, .. } => Some(source),
            Self::AbortCleanupFailed { cleanup, .. } => Some(cleanup),
            Self::RuntimeLockPoisoned
            | Self::SingleProducerHandleRequired
            | Self::SingleProducerModeDisabled
            | Self::SingleProducerAlreadyClaimed
            | Self::AllocationFailed
            | Self::MissingReadMyWrites
            | Self::MissingOpacity
            | Self::ForeignBackendKey
            | Self::RebuildRequired
            | Self::InvalidGcOptions
            | Self::WalRequired
            | Self::UnsupportedTable(_)
            | Self::BackendStateMismatch
            | Self::RecoveryDiverged => None,
        }
    }
}

impl From<LocalError> for Error {
    fn from(value: LocalError) -> Self {
        Self::Native(value)
    }
}

impl From<BlobError> for Error {
    fn from(value: BlobError) -> Self {
        Self::Backend(value)
    }
}

impl From<RecordError> for Error {
    fn from(value: RecordError) -> Self {
        Self::Record(value)
    }
}

impl From<WritebackConfigError> for Error {
    fn from(value: WritebackConfigError) -> Self {
        Self::WritebackConfig(value)
    }
}

impl From<ReserveError> for Error {
    fn from(value: ReserveError) -> Self {
        Self::Reserve(value)
    }
}

impl From<ResolveError> for Error {
    fn from(value: ResolveError) -> Self {
        Self::Resolve(value)
    }
}

impl From<ApplyError> for Error {
    fn from(value: ApplyError) -> Self {
        Self::Apply(value)
    }
}

impl From<RuntimeError> for Error {
    fn from(value: RuntimeError) -> Self {
        Self::Runtime(value)
    }
}

/// Transaction cache with an exclusively owned backend.
///
/// Applications construct [`Db`] with [`Db::open`]. The cache opens RocksDB
/// internally and never exposes a backend handle, so callers cannot bypass
/// Silo, the commit log, or timestamp checks by writing directly to RocksDB.
/// Backend injection is available only through the opt-in `test-support`
/// feature for fault and recovery tests.
///
/// The backend cannot be obtained from an open cache:
///
/// ```compile_fail,E0599
/// fn bypass(cache: &mako_cache::Db) {
///     let _backend = cache.backend();
/// }
/// ```
///
/// Callers also cannot construct a cache with a retained writable handle:
///
/// ```compile_fail,E0624
/// use std::sync::Arc;
/// use mako_cache::{Cache, CacheOptions};
/// use mrx_core::fakes::MemBlobs;
/// let backend = Arc::new(MemBlobs::new());
/// let cache = Cache::from_backend(Arc::clone(&backend), CacheOptions::default());
/// ```
///
/// This local milestone supports one recovered cache namespace per
/// process. Native tables and the Mako timestamp authority are process-wide;
/// independently reopening another pre-existing backend after transactions
/// have begun cannot retroactively establish one timestamp history. A future
/// multi-cache supervisor must preflight every backend before admitting work.
pub struct Cache<B: Blobs + 'static> {
    local: LocalDb,
    writeback: Arc<WritebackSet<B>>,
    runtime: Mutex<Option<Runtime<WritebackSet<B>>>>,
    record_checksum: RecordChecksum,
    foreground_mode: ForegroundMode,
    backend_stall_threshold: Duration,
    /// Lease acquisition is a cold, once-per-owner operation. The lease
    /// itself is thread-affine, so ordinary transactions pay no owner atomic.
    single_producer_claimed: AtomicBool,
    // Common writers publish only to their thread-private fence cache line.
    // Read-only/no-op commits take independent order cuts and drain registered
    // slots so they cannot pass an unresolved prefix writer's outcome.
    commit_fence: CommitFence,
}

/// Production cache using RocksDB as its asynchronous backend.
pub type Db = Cache<RocksBlobs>;

impl Cache<RocksBlobs> {
    /// Open or create a RocksDB-backed transaction cache.
    pub fn open<P: AsRef<Path>>(path: P, options: Options) -> Result<Self, Error> {
        validate_gc_options(options.cache)?;
        if options.durability == Durability::None {
            return Err(Error::WalRequired);
        }
        let backend = RocksBlobs::open(path.as_ref(), options.durability)?;
        Self::from_backend(backend, options.cache)
    }
}

impl<B: Blobs + 'static> Cache<B> {
    /// Open over an already constructed atomic backend.
    ///
    /// Recovery and validation complete before the background writer starts
    /// or this cache becomes accessible to callers. The Phase 1 process model
    /// permits only one pre-existing cache namespace; see [`Cache`].
    #[allow(unsafe_code)]
    fn from_backend(backend: B, options: CacheOptions) -> Result<Self, Error> {
        validate_gc_options(options)?;
        let features = mako_engine::features()?;
        if options.require_read_my_writes
            && (!features.read_my_writes() || !features.scan_read_my_writes())
        {
            return Err(Error::MissingReadMyWrites);
        }
        if options.isolation == Isolation::Opaque && !features.opacity() {
            return Err(Error::MissingOpacity);
        }

        let local = LocalDb::open()?;
        // Claim before recovery mutates process-local tables or exposes work.
        // Native enforces the documented one-cache-namespace process model.
        let cache_order_mode = match options.foreground_mode {
            ForegroundMode::Concurrent => mako_engine::CacheOrderMode::PerWorker,
            ForegroundMode::SingleProducer => mako_engine::CacheOrderMode::SingleProducer,
        };
        // SAFETY: construction exclusively owns the fresh facade and fixes
        // foreground mode for the complete Cache lifetime.
        unsafe { local.claim_cache_order_namespace(cache_order_mode)? };
        let recovered = recover(&local, &backend, options.writeback.max_record_bytes)?;
        // SAFETY: construction still exclusively owns the claimed LocalDb;
        // no foreground handle or ordering terminal exists until return.
        let native_sequence_seed = if options.foreground_mode == ForegroundMode::SingleProducer {
            recovered.legacy.local_tail
        } else {
            0
        };
        unsafe { local.reseed_cache_order_namespace(native_sequence_seed)? };
        local.bind_trusted_table(DEFAULT_TABLE_NAME, DEFAULT_TABLE_ID)?;
        let writeback = Arc::new(WritebackSet::new_with_gc(
            backend,
            recovered,
            options.writeback,
            options.foreground_mode == ForegroundMode::Concurrent,
            options.log_retention,
            options.gc_interval,
        )?);
        let runtime = Runtime::start_on_cpu(Arc::clone(&writeback), options.writeback_cpu)
            .map_err(Error::RuntimeStart)?;

        Ok(Self {
            local,
            writeback,
            runtime: Mutex::new(Some(runtime)),
            record_checksum: options.record_checksum,
            foreground_mode: options.foreground_mode,
            backend_stall_threshold: options.backend_stall_threshold,
            single_producer_claimed: AtomicBool::new(false),
            commit_fence: CommitFence::new(),
        })
    }

    /// Claim the explicit foreground lease for a single-producer cache.
    ///
    /// At most one lease exists at a time. The returned handle is neither
    /// [`Send`] nor [`Sync`], and transactions borrow it, so safe Rust cannot
    /// overlap foreground commits or move the producer to another thread. A
    /// lease may be dropped and reacquired after all of its transactions end.
    pub fn single_producer(&self) -> Result<SingleProducer<'_, B>, Error> {
        if self.foreground_mode != ForegroundMode::SingleProducer {
            return Err(Error::SingleProducerModeDisabled);
        }
        self.single_producer_claimed
            .compare_exchange(false, true, Ordering::Acquire, Ordering::Relaxed)
            .map_err(|_| Error::SingleProducerAlreadyClaimed)?;
        Ok(SingleProducer {
            cache: self,
            state: self.writeback.single_lane().producer(),
            _thread_affine: PhantomData,
        })
    }

    /// Begin one optimistic transaction on the current OS thread.
    ///
    /// Transactions are structurally neither `Send` nor `Sync`; they must be
    /// completed on the worker that began them and should not cross `.await`.
    /// A cache opened with [`ForegroundMode::SingleProducer`] must instead use
    /// [`SingleProducer::transaction`].
    pub fn transaction(&self) -> Result<Transaction<'_, B>, Error> {
        if self.foreground_mode == ForegroundMode::SingleProducer {
            return Err(Error::SingleProducerHandleRequired);
        }
        // This is an early fail-fast check. Commit rechecks under its outcome
        // fence, which closes the race with an in-flight ambiguous writer.
        self.writeback.ensure_no_unknown()?;
        let (table, native) = self.local.trusted_bound_transaction()?;
        let worker_slot = CommitFence::try_current_thread_slot()?;
        let lane = self.writeback.lane(worker_slot)?;
        // The cache and table borrows establish the invariants required by
        // mako-local's build-private trusted Put path. Public cache semantics
        // are unchanged: reads/scans and conditional mutations still use the
        // checked ABI, and commit retains separate visibility/cleanup results.
        Ok(Transaction {
            cache: self,
            writeback: lane.writeback(),
            table,
            native: Some(native),
            foreground: TransactionForeground::Concurrent(lane.producer()),
        })
    }

    /// Read one key through a read-only transaction.
    pub fn get(&self, key: &[u8]) -> Result<Option<Vec<u8>>, Error> {
        let mut transaction = self.transaction()?;
        let value = transaction.get(key)?;
        transaction.commit()?;
        Ok(value)
    }

    /// Upsert one key in its own transaction.
    pub fn put(&self, key: &[u8], value: &[u8]) -> Result<(), Error> {
        let mut transaction = self.transaction()?;
        transaction.put(key, value)?;
        transaction.commit()
    }

    /// Insert one key if absent, returning whether it was inserted.
    pub fn insert(&self, key: &[u8], value: &[u8]) -> Result<bool, Error> {
        let mut transaction = self.transaction()?;
        let inserted = transaction.insert(key, value)?;
        transaction.commit()?;
        Ok(inserted)
    }

    /// Delete one key, returning whether a live value existed.
    pub fn delete(&self, key: &[u8]) -> Result<bool, Error> {
        let mut transaction = self.transaction()?;
        let existed = transaction.remove(key)?;
        transaction.commit()?;
        Ok(existed)
    }

    /// Wait until every transaction acknowledged before this call has been
    /// applied to RocksDB.
    ///
    /// This drains only the in-memory queue. It does not flush or sync
    /// RocksDB; the selected [`Durability`] controls the ordinary batch-write
    /// options.
    pub fn wait_applied(&self) -> Result<u64, Error> {
        Ok(self.writeback.wait_applied()?)
    }

    /// Compatibility spelling for [`Self::wait_applied`].
    ///
    /// Despite the name, this adds no RocksDB flush or sync beyond the
    /// configured ordinary batch writes.
    pub fn flush(&self) -> Result<u64, Error> {
        self.wait_applied()
    }

    /// Current in-memory progress of the RocksDB consumer.
    ///
    /// Concurrent workers have independent physical log lanes. In that mode,
    /// the sequence is the total applied record count and the timestamp is the
    /// greatest applied Mako timestamp, not a claim of a contiguous global
    /// serialization prefix.
    pub fn applied_watermark(&self) -> AppliedWatermark {
        self.writeback.applied_watermark()
    }

    /// Number of cache transactions applied to RocksDB.
    pub fn applied_sequence(&self) -> u64 {
        self.writeback.applied_watermark().sequence()
    }

    /// Number of cache transactions acknowledged to foreground callers.
    ///
    /// [`Self::wait_applied`] snapshots every initialized worker lane and waits
    /// for each lane through its acknowledged position.
    pub fn highest_acknowledged_sequence(&self) -> u64 {
        self.writeback.highest_acknowledged()
    }

    /// Number of bound prepared, ready, or applying slots across initialized
    /// lanes.
    pub fn queued_transactions(&self) -> usize {
        self.writeback.queue_len()
    }

    /// Read operational health and progress without draining the cache.
    ///
    /// A transient backend or record-allocation failure reports
    /// [`CacheHealth::Degraded`] while the dedicated writer retries the exact
    /// front batch. A permanent record or commit-outcome failure, or an
    /// unexpectedly stopped writer, reports [`CacheHealth::Unhealthy`]. This
    /// call never flushes or syncs RocksDB.
    pub fn status(&self) -> Result<CacheStatus, Error> {
        let runtime = {
            let runtime = self
                .runtime
                .lock()
                .map_err(|_| Error::RuntimeLockPoisoned)?;
            runtime.as_ref().map(Runtime::snapshot).unwrap_or_default()
        };

        let writeback_error = self.writeback.ensure_no_unknown().err();
        let apply = self.writeback.apply_telemetry();
        let log_gc = self.writeback.gc_snapshot();
        let backend_stalled = apply
            .in_progress
            .is_some_and(|(_, elapsed)| elapsed >= self.backend_stall_threshold);
        let engine_runtime_healthy = self.local.runtime_is_healthy();
        let health = if !engine_runtime_healthy || !runtime.running || writeback_error.is_some() {
            CacheHealth::Unhealthy
        } else if runtime.consecutive_failures != 0
            || apply.pending_retry.is_some()
            || !apply.active_retryable_failures.is_empty()
            || backend_stalled
            || log_gc.pending_retry
            || log_gc.active_error
            || log_gc
                .in_progress
                .is_some_and(|elapsed| elapsed >= self.backend_stall_threshold)
        {
            CacheHealth::Degraded
        } else {
            CacheHealth::Healthy
        };

        Ok(CacheStatus {
            health,
            engine_runtime_healthy,
            background_writer_running: runtime.running,
            backend_failures: apply.backend_failures,
            record_failures: apply.record_failures,
            runtime_loop_panics: apply.runtime_loop_panics,
            consecutive_background_failures: runtime.consecutive_failures,
            pending_backend_retry: apply.pending_retry,
            active_retryable_failures: apply.active_retryable_failures,
            backend_write_in_progress: apply
                .in_progress
                .map(|(sequence, elapsed)| BackendWriteInProgress { sequence, elapsed }),
            backend_stall_threshold: self.backend_stall_threshold,
            last_failure: apply.last_failure,
            writeback_error,
            applied_watermark: self.writeback.applied_watermark(),
            acknowledged_transactions: self.writeback.highest_acknowledged(),
            queued_transactions: self.writeback.queue_len(),
            log_gc,
            quarantined_workers: mako_engine::quarantined_worker_count()?,
        })
    }

    /// Observe the backend's current database-file sizes, when supported.
    ///
    /// This performs filesystem I/O and is separate from nonblocking status.
    /// The size includes retained WAL/SST/metadata files and is not an exact
    /// measure of allocated disk blocks. Compaction may change it concurrently.
    pub fn disk_usage_bytes(&self) -> Result<Option<u64>, Error> {
        self.writeback.disk_usage_bytes().map_err(Error::Backend)
    }

    /// Internal crash tests use this to rendezvous with RocksDB test hooks.
    #[cfg(test)]
    fn backend(&self) -> &B {
        self.writeback.backend()
    }

    /// Attempt to drain every acknowledged lane snapshot and stop the writer.
    ///
    /// Success means every captured acknowledgement reached RocksDB. An error
    /// means the synchronous retry budget or another shutdown invariant failed;
    /// because this operation consumes the cache, recovery requires reopening
    /// it. A backend call that never returns can block this operation.
    pub fn close(self) -> Result<u64, Error> {
        self.shutdown()
    }

    /// Stop without draining, modelling loss of the volatile queue on crash.
    ///
    /// This is intended for crash tests and controlled process teardown.
    /// Acknowledged records not yet applied in any lane may be lost.
    #[doc(hidden)]
    pub fn abort_without_flush(self) -> Result<(), Error> {
        self.writeback.reclaim_credits_for_shutdown();
        let mut runtime = self
            .runtime
            .lock()
            .map_err(|_| Error::RuntimeLockPoisoned)?;
        if let Some(mut runtime) = runtime.take() {
            runtime.abort()?;
        }
        Ok(())
    }

    fn shutdown(&self) -> Result<u64, Error> {
        self.writeback.reclaim_credits_for_shutdown();
        let mut runtime = self
            .runtime
            .lock()
            .map_err(|_| Error::RuntimeLockPoisoned)?;
        match runtime.take() {
            Some(mut runtime) => Ok(runtime.shutdown()?),
            None => Ok(self.writeback.applied_watermark().sequence()),
        }
    }
}

/// Exclusive foreground capability for a
/// [`ForegroundMode::SingleProducer`] cache.
///
/// The handle is deliberately neither [`Send`] nor [`Sync`]. Its transaction
/// method also requires a mutable borrow, so safe Rust can have neither a
/// second producer thread nor two simultaneously live detached reservations:
///
/// ```compile_fail
/// # fn require_send<T: Send>() {}
/// require_send::<mako_cache::SingleProducer<
///     'static,
///     std::sync::Arc<mrx_core::fakes::MemBlobs>,
/// >>();
/// ```
///
/// ```compile_fail
/// # fn require_sync<T: Sync>() {}
/// require_sync::<mako_cache::SingleProducer<
///     'static,
///     std::sync::Arc<mrx_core::fakes::MemBlobs>,
/// >>();
/// ```
pub struct SingleProducer<'cache, B: Blobs + 'static> {
    cache: &'cache Cache<B>,
    state: &'cache writeback::SingleProducerState,
    _thread_affine: PhantomData<Rc<()>>,
}

impl<'cache, B: Blobs + 'static> SingleProducer<'cache, B> {
    /// Begin one optimistic transaction on this foreground producer.
    ///
    /// The mutable borrow keeps the queue's pre-validation capacity promise
    /// unique until the transaction aborts or binds its exact dense sequence.
    pub fn transaction(&mut self) -> Result<Transaction<'_, B>, Error> {
        // The unique foreground lease prevents another terminal from passing
        // us. Commit performs the authoritative health check immediately
        // before native validation; repeating it here would add an Acquire to
        // every one-operation transaction without closing any additional
        // race. Concurrent transactions retain their early fail-fast check in
        // `Cache::transaction_with`.
        let (table, native) = self.cache.local.trusted_bound_transaction()?;
        Ok(Transaction {
            cache: self.cache,
            writeback: self.cache.writeback.single_lane().writeback(),
            table,
            native: Some(native),
            foreground: TransactionForeground::SingleProducer(self.state),
        })
    }

    /// Read one key through a read-only transaction.
    pub fn get(&mut self, key: &[u8]) -> Result<Option<Vec<u8>>, Error> {
        let mut transaction = self.transaction()?;
        let value = transaction.get(key)?;
        transaction.commit()?;
        Ok(value)
    }

    /// Upsert one key in its own transaction.
    pub fn put(&mut self, key: &[u8], value: &[u8]) -> Result<(), Error> {
        let mut transaction = self.transaction()?;
        transaction.put(key, value)?;
        transaction.commit()
    }

    /// Insert one key if absent, returning whether it was inserted.
    pub fn insert(&mut self, key: &[u8], value: &[u8]) -> Result<bool, Error> {
        let mut transaction = self.transaction()?;
        let inserted = transaction.insert(key, value)?;
        transaction.commit()?;
        Ok(inserted)
    }

    /// Delete one key, returning whether a live value existed.
    pub fn delete(&mut self, key: &[u8]) -> Result<bool, Error> {
        let mut transaction = self.transaction()?;
        let existed = transaction.remove(key)?;
        transaction.commit()?;
        Ok(existed)
    }

    /// Wait until every transaction acknowledged before this call has been
    /// applied to the asynchronous backend.
    pub fn wait_applied(&self) -> Result<u64, Error> {
        self.cache.wait_applied()
    }

    /// Current in-memory applied watermark.
    pub fn applied_watermark(&self) -> AppliedWatermark {
        self.cache.applied_watermark()
    }

    /// Highest dense cache sequence acknowledged to foreground callers.
    pub fn highest_acknowledged_sequence(&self) -> u64 {
        self.cache.highest_acknowledged_sequence()
    }
}

impl<B: Blobs + 'static> Drop for SingleProducer<'_, B> {
    fn drop(&mut self) {
        self.cache
            .single_producer_claimed
            .store(false, Ordering::Release);
    }
}

impl<B: Blobs + 'static> Drop for Cache<B> {
    fn drop(&mut self) {
        if let Err(error) = self.shutdown() {
            eprintln!(
                "mako-cache: acknowledged transactions were not applied at shutdown: {error}"
            );
        }
    }
}

#[derive(Clone, Copy)]
enum TransactionForeground<'cache> {
    Concurrent(&'cache writeback::SingleProducerState),
    SingleProducer(&'cache writeback::SingleProducerState),
}

impl<'cache> TransactionForeground<'cache> {
    const fn is_concurrent(self) -> bool {
        matches!(self, Self::Concurrent(_))
    }

    const fn producer(self) -> &'cache writeback::SingleProducerState {
        match self {
            Self::Concurrent(state) | Self::SingleProducer(state) => state,
        }
    }
}

/// One single-table cache transaction backed by native Silo.
///
/// Keep every field borrowed or trivially droppable. The exact fused success
/// path forgets this facade after native consumes its only owned resource. A
/// future RAII field must be released or transferred before that fast return.
pub struct Transaction<'db, B: Blobs + 'static> {
    cache: &'db Cache<B>,
    writeback: &'db Writeback<Arc<B>>,
    table: mako_engine::Table<'db>,
    native: Option<mako_engine::Transaction<'db>>,
    foreground: TransactionForeground<'db>,
}

/// A transactional range iterator over the cache's default table.
///
/// Forward and reverse scans both use the logical binary-key range `[lower,
/// upper)`. Items own their key and value bytes. The iterator exclusively
/// borrows its transaction until it is consumed or dropped.
pub struct Scan<'txn, 'db> {
    inner: mako_engine::Scan<'txn, 'db>,
}

impl Iterator for Scan<'_, '_> {
    type Item = Result<(Vec<u8>, Vec<u8>), Error>;

    fn next(&mut self) -> Option<Self::Item> {
        self.inner
            .next()
            .map(|result| result.map_err(Error::Native))
    }
}

impl<'db, B: Blobs + 'static> Transaction<'db, B> {
    fn native_mut(&mut self) -> &mut mako_engine::Transaction<'db> {
        self.native
            .as_mut()
            .expect("cache transaction already consumed")
    }

    /// Read a key, distinguishing missing from present-empty.
    pub fn get(&mut self, key: &[u8]) -> Result<Option<Vec<u8>>, Error> {
        let table = self.table;
        Ok(self.native_mut().get(&table, key)?)
    }

    /// Scan `[lower, upper)` in ascending binary-key order.
    ///
    /// `None` means no upper bound. Earlier writes staged by this transaction
    /// are reflected in the results.
    pub fn scan<'txn>(
        &'txn mut self,
        lower: &[u8],
        upper: Option<&[u8]>,
    ) -> Result<Scan<'txn, 'db>, Error> {
        let table = self.table;
        Ok(Scan {
            inner: self.native_mut().scan(&table, lower, upper)?,
        })
    }

    /// Scan `[lower, upper)` in descending binary-key order.
    ///
    /// The lower endpoint remains inclusive and the upper endpoint exclusive.
    pub fn rscan<'txn>(
        &'txn mut self,
        lower: &[u8],
        upper: Option<&[u8]>,
    ) -> Result<Scan<'txn, 'db>, Error> {
        let table = self.table;
        Ok(Scan {
            inner: self.native_mut().rscan(&table, lower, upper)?,
        })
    }

    /// Upsert a key, returning whether it was newly created.
    pub fn put(&mut self, key: &[u8], value: &[u8]) -> Result<bool, Error> {
        let table = self.table;
        Ok(self.native_mut().put(&table, key, value)?)
    }

    /// Insert a key only when absent, returning whether it was staged.
    pub fn insert(&mut self, key: &[u8], value: &[u8]) -> Result<bool, Error> {
        let table = self.table;
        Ok(self.native_mut().insert(&table, key, value)?)
    }

    /// Remove a key, returning whether a live value existed.
    pub fn remove(&mut self, key: &[u8]) -> Result<bool, Error> {
        let table = self.table;
        Ok(self.native_mut().remove(&table, key)?)
    }

    /// Validate/install in Silo, then publish the preallocated write-back
    /// record before returning success.
    #[allow(unsafe_code)]
    #[inline(always)]
    pub fn commit(mut self) -> Result<(), Error> {
        let foreground = self.foreground;
        let fused_candidate = self.cache.record_checksum == RecordChecksum::None
            && unsafe {
                self.native
                    .as_ref()
                    .unwrap_unchecked()
                    .trusted_unchecked_one_put_record_bytes_candidate()
            }
            .is_some_and(|bytes| bytes.get() as usize <= self.writeback.max_record_bytes());
        if fused_candidate {
            let producer = foreground.producer();
            let _fence = foreground
                .is_concurrent()
                .then(|| self.cache.commit_fence.enter_writer());
            if let Err(error) = self.cache.writeback.ensure_no_unknown() {
                let native = unsafe { self.native.take().unwrap_unchecked() };
                return Err(abort_after_precommit_failure(native, Error::Apply(error)));
            }
            #[cfg(test)]
            crate::failpoint::hit(crate::failpoint::Point::BeforeDetachedPreparation);

            let mut cold_attempt = std::mem::MaybeUninit::uninit();
            #[cfg(test)]
            let writeback = self.writeback;
            // SAFETY: this transaction borrows the unique thread-affine
            // producer for its whole lifetime. The producer control and
            // both local atomic words remain stable with the borrowed
            // cache through this synchronous attempt. On true, native has
            // consumed the raw handle and this branch immediately forgets
            // the outer facade with its stale native ownership state. On
            // false, the Rust wrapper initializes the cold lifecycle value
            // before it is read below; native only initializes control
            // scratch for consumed cold codes.
            let published = unsafe {
                self.native
                    .as_mut()
                    .unwrap_unchecked()
                    .try_commit_trusted_fused_single_producer_one_put_holder_fast_forget_on_publish(
                        producer.fused_holder_control(),
                        producer.next_sequence_ptr(),
                        producer.capacity_limit_ptr(),
                        &mut cold_attempt,
                    )
            };
            if published {
                // Native destroyed the only owned resource. Every
                // remaining field is borrowed or scalar. Forget first so
                // even a test notifier panic cannot drop the stale native
                // facade. A future owned field must be released or
                // transferred before this point.
                std::mem::forget(self);
                #[cfg(test)]
                writeback.notify_fused_holder_published_for_test();
                return Ok(());
            }
            // SAFETY: guaranteed by the false fast-terminal result.
            let attempt = unsafe { cold_attempt.assume_init() };
            return self.finish_single_producer_fused_cold(
                producer,
                attempt,
                foreground.is_concurrent(),
            );
        }
        self.commit_general()
    }

    /// Fused monomorphic terminal for the latency-sensitive one-Put SPSC ACK.
    ///
    /// The ordinary success path crosses native once and returns only one
    /// scalar lifecycle code. Candidate selection, the capacity check, holder
    /// commit, post-commit health ordering, and ACK publication all remain in
    /// that call. Every fallible or anomalous case is routed to the existing
    /// cold Rust protocol.
    #[allow(unsafe_code)]
    #[cold]
    #[inline(never)]
    fn finish_single_producer_fused_cold(
        mut self,
        producer: &writeback::SingleProducerState,
        mut attempt: mako_engine::TrustedFusedOnePutHolderAttempt,
        writer_fence_active: bool,
    ) -> Result<(), Error> {
        loop {
            match attempt {
                mako_engine::TrustedFusedOnePutHolderAttempt::Published => std::process::abort(),
                mako_engine::TrustedFusedOnePutHolderAttempt::UntouchedGeneral => {
                    return self.commit_general_inner(writer_fence_active);
                }
                mako_engine::TrustedFusedOnePutHolderAttempt::UntouchedSlow {
                    exact_record_bytes,
                } => {
                    if let Err(error) = self.cache.writeback.ensure_no_unknown() {
                        let native = unsafe { self.native.take().unwrap_unchecked() };
                        return Err(abort_after_precommit_failure(native, Error::Apply(error)));
                    }
                    match self
                        .writeback
                        .reserve_native_holder_single_slow(producer, exact_record_bytes)
                    {
                        Ok(sequence) => {
                            debug_assert_eq!(sequence, producer.retained_sequence());
                            // The cold reservation changes no shared ownership;
                            // it refreshes cached applied capacity and the same
                            // still-active transaction retries the fused gate.
                            let mut cold_attempt = std::mem::MaybeUninit::uninit();
                            #[cfg(test)]
                            let writeback = self.writeback;
                            // SAFETY: the first fused attempt established this
                            // method's unique-producer and stable-pointer
                            // invariants. The successful slow reservation
                            // changes no ownership and permits this one retry.
                            let published = unsafe {
                                self.native
                                    .as_mut()
                                    .unwrap_unchecked()
                                    .try_commit_trusted_fused_single_producer_one_put_holder_fast_forget_on_publish(
                                        producer.fused_holder_control(),
                                        producer.next_sequence_ptr(),
                                        producer.capacity_limit_ptr(),
                                        &mut cold_attempt,
                                    )
                            };
                            if published {
                                std::mem::forget(self);
                                #[cfg(test)]
                                writeback.notify_fused_holder_published_for_test();
                                return Ok(());
                            }
                            // SAFETY: guaranteed by the false retry result.
                            attempt = unsafe { cold_attempt.assume_init() };
                            continue;
                        }
                        Err(error) => {
                            // Native explicitly left this handle active.
                            let native = unsafe { self.native.take().unwrap_unchecked() };
                            return Err(abort_after_precommit_failure(
                                native,
                                Error::Reserve(error),
                            ));
                        }
                    }
                }
                mako_engine::TrustedFusedOnePutHolderAttempt::CommittedUnpublished {
                    timestamp,
                    exact_record_bytes,
                } => {
                    // Native consumed the handle, and the cold decoder advanced
                    // the producer-local cursor. A concurrent fail-stop latch
                    // prevented ACK publication.
                    finish_committed_native_holder_cold(
                        self.writeback,
                        producer.accepted_sequence(),
                        timestamp,
                        exact_record_bytes,
                    )?;
                    return Ok(());
                }
                mako_engine::TrustedFusedOnePutHolderAttempt::ConsumedOutcome {
                    outcome,
                    exact_record_bytes,
                } => {
                    // The cold decoder synchronized the producer-local cursor
                    // to the pre-acceptance ACK. The established resolver can
                    // now accept or pin only when the timestamp proves that
                    // native installed the write.
                    finish_holder_outcome_cold(
                        self.writeback,
                        producer,
                        producer.retained_sequence(),
                        exact_record_bytes,
                        outcome,
                    )?;
                    return Ok(());
                }
                mako_engine::TrustedFusedOnePutHolderAttempt::UntouchedMalformed
                | mako_engine::TrustedFusedOnePutHolderAttempt::ConsumedMalformed => {
                    // Ownership is known, but same-build lifecycle metadata is
                    // not. Continuing could either reuse an accepted holder or
                    // touch a consumed facade; terminate fail-closed.
                    std::process::abort();
                }
            }
        }
    }

    #[inline(never)]
    #[allow(unsafe_code)]
    fn commit_general(&mut self) -> Result<(), Error> {
        self.commit_general_inner(false)
    }

    #[inline(never)]
    #[allow(unsafe_code)]
    fn commit_general_inner(&mut self, writer_fence_active: bool) -> Result<(), Error> {
        let foreground = self.foreground;
        let mut native = self
            .native
            .take()
            .expect("cache transaction already consumed");
        // The common unchecked one-Put case carries its exact canonical v6
        // extent out of the trusted Put itself. Native independently rederives
        // that shape at the consuming terminal, so we can avoid a second ABI
        // call and plan-sealing pass without trusting Rust for write coverage.
        // Every other transaction retains the general canonical preflight.
        let max_record_bytes = self.writeback.max_record_bytes();
        let unchecked_one_put = (self.cache.record_checksum == RecordChecksum::None)
            .then(|| native.unchecked_one_put_record_candidate())
            .flatten()
            .filter(|candidate| candidate.exact_record_bytes() <= max_record_bytes);
        let preflight = match unchecked_one_put {
            Some(preflight) => preflight,
            None => native.commit_record_preflight_with_checksum(
                max_record_bytes,
                self.cache.record_checksum,
            )?,
        };

        if preflight.is_empty() {
            if foreground.is_concurrent() {
                // Mark one packed cache-order cut, then drain every
                // writer ordered before it. A later writer may proceed: STO
                // either orders it after this read-only transaction or makes
                // the read-set/predicate validation reject this commit.
                self.cache.commit_fence.close_for_read_only(|| {
                    self.cache.local.order_record_validation_prefix();
                });
                if let Err(error) = self.cache.writeback.ensure_no_unknown() {
                    return Err(abort_after_precommit_failure(native, Error::Apply(error)));
                }
                return finish_read_only(native);
            }
            // The mutable thread-affine producer lease excludes every writer
            // and read-only commit, so no outcome fence is needed.
            if let Err(error) = self.cache.writeback.ensure_no_unknown() {
                return Err(abort_after_precommit_failure(native, Error::Apply(error)));
            }
            return finish_read_only(native);
        }

        #[cfg(test)]
        crate::failpoint::hit(crate::failpoint::Point::BeforeDetachedPreparation);

        // Each concurrent worker owns one SPSC lane. The outcome fence remains
        // global only so a read-only commit can close a timestamp-order cut.
        let _fence = (foreground.is_concurrent() && !writer_fence_active)
            .then(|| self.cache.commit_fence.enter_writer());
        if let Err(error) = self.cache.writeback.ensure_no_unknown() {
            return Err(abort_after_precommit_failure(native, Error::Apply(error)));
        }

        // The same callback-free holder terminal is safe for one producer per
        // lane. Native's PerWorker mode supplies timestamp ordering against
        // other lanes and the general validation gate.
        if unchecked_one_put.is_some() {
            let producer = foreground.producer();
            let exact_record_bytes = NonZeroU32::new(preflight.exact_record_bytes() as u32)
                .expect("a trusted one-Put record has a nonzero u32 extent");
            match self
                .writeback
                .reserve_native_holder_single_slow(producer, exact_record_bytes)
            {
                Ok(sequence) => {
                    return finish_trusted_one_put_holder_single(
                        self.writeback,
                        native,
                        exact_record_bytes,
                        producer,
                        sequence,
                        foreground.is_concurrent(),
                    );
                }
                Err(error) => {
                    return Err(abort_after_precommit_failure(native, Error::Reserve(error)));
                }
            }
        }

        // Capacity waits and buffer checkout/growth complete before native Silo
        // takes write locks. Common records use a queue-capacity fixed arena;
        // oversized buffers are recycled after background application.
        let reserved = self
            .writeback
            .reserve_native_single(foreground.producer(), preflight.exact_record_bytes());
        let mut permit = match reserved {
            Ok(permit) => permit,
            Err(error) => {
                return Err(abort_after_precommit_failure(native, Error::Reserve(error)));
            }
        };
        #[cfg(test)]
        crate::failpoint::hit(crate::failpoint::Point::DetachedPrepared);

        if let Err(error) = self.cache.writeback.ensure_no_unknown() {
            return Err(abort_after_precommit_failure(native, Error::Apply(error)));
        }

        let mut bound = None;
        let mut bind_error = None;
        let acquire_target = |timestamp, native_preflight| {
            debug_assert_eq!(native_preflight, preflight);
            match permit.bind_native(timestamp) {
                Ok(mut reservation) => {
                    // SAFETY: this reservation remains alive in `bound`
                    // through the synchronous native terminal.
                    let target = unsafe { reservation.native_record_target() };
                    bound = Some(reservation);
                    #[cfg(test)]
                    crate::failpoint::hit(crate::failpoint::Point::PreinstallBound);
                    Some(target)
                }
                Err(error) => {
                    bind_error = Some(error);
                    None
                }
            }
        };
        let record_report = if unchecked_one_put.is_some() {
            unsafe {
                native.commit_report_with_unchecked_one_put_record_target(preflight, acquire_target)
            }
        } else {
            unsafe { native.commit_report_with_record_target(acquire_target) }
        };
        enforce_record_completion_contract(&record_report);
        let report = record_report.commit;
        assert_eq!(
            record_report.record_bound,
            bound.is_some(),
            "native and queue record-binding outcomes diverged"
        );
        #[cfg(test)]
        crate::failpoint::observe_post_native_commit();
        #[cfg(test)]
        if bound.is_some() {
            crate::failpoint::hit(crate::failpoint::Point::NativeCommittedBeforeReady);
        }

        if let Some(reservation) = bound.as_mut() {
            if !record_report.record_written {
                // A sequence was assigned but native did not prove complete
                // initialization. Dropping the reservation pins the ordered
                // slot; treating this as an abort could let later data pass a
                // possibly visible transaction with no replayable record.
                return Err(finish_unwritten_bound(reservation, record_report));
            }
            // SAFETY: completion-contract enforcement above and the explicit
            // record_written branch prove native initialized the exact target.
            unsafe { reservation.attach_written_native_record() };
            return match report.disposition {
                CommitDisposition::Committed => {
                    let sequence = reservation.publish()?;
                    match report.cleanup {
                        Ok(()) => Ok(()),
                        Err(source) => Err(Error::CommittedButCleanupFailed { sequence, source }),
                    }
                }
                // Once the hook returned true, phase 3 may have started. Even
                // a nominal CONFLICT is no longer safe to cancel or skip.
                CommitDisposition::Aborted(source) | CommitDisposition::Unknown(source) => {
                    let sequence = reservation.pin_unknown()?;
                    Err(Error::UnknownCommitOutcome {
                        sequence,
                        source,
                        cleanup: report.cleanup.err(),
                    })
                }
            };
        }

        if let Some(error) = bind_error {
            // The hook returned false, so native installation never began.
            debug_assert!(matches!(
                report.disposition,
                CommitDisposition::Aborted(LocalError::CommitHookRejected)
            ));
            return match report.cleanup {
                Ok(()) => Err(Error::Reserve(error)),
                Err(cleanup) => Err(Error::AbortCleanupFailed {
                    abort: LocalError::CommitHookRejected,
                    cleanup,
                }),
            };
        }

        // A nonempty native preflight implies a write set. If no bind callback
        // ran, Silo never entered installation, so every failure is a definite
        // visibility abort even when the generic wrapper labels cleanup as
        // Unknown. A committed result without a record is an uncovered-write
        // contract violation.
        match report.disposition {
            CommitDisposition::Committed => {
                panic!("native write commit succeeded without invoking its pre-install hook")
            }
            CommitDisposition::Aborted(abort) | CommitDisposition::Unknown(abort) => {
                match report.cleanup {
                    Ok(()) => Err(Error::Native(abort)),
                    Err(cleanup) => Err(Error::AbortCleanupFailed { abort, cleanup }),
                }
            }
        }
    }

    /// Explicitly abort without creating a write-back obligation.
    pub fn abort(mut self) -> Result<(), Error> {
        self.native
            .take()
            .expect("cache transaction already consumed")
            .abort()?;
        Ok(())
    }
}

/// Complete the cache-private concurrent one-Put terminal.
///
/// Native returns an accepted Mako timestamp and physical queue sequence after
/// validation. Their orders may diverge. Native acquires the exact publication
/// generation only after assigning the sequence, then transfers the staged
/// value allocation into a holder
/// that remains owned through backend retirement. The byte arena remains the
/// compatibility path for an unrepresentable holder tag or crash failpoint.
#[allow(unsafe_code)]
fn finish_trusted_one_put_concurrent<'cache, 'db, B: Blobs + 'static>(
    cache: &'cache Cache<B>,
    writeback: &'cache Writeback<Arc<B>>,
    native: mako_engine::Transaction<'db>,
    preflight: mako_engine::CommitRecordPreflight,
    permit: writeback::NativeArenaPermit<'cache, B>,
    worker_slot: usize,
) -> Result<(), Error> {
    #[cfg(test)]
    crate::failpoint::hit(crate::failpoint::Point::DetachedPrepared);

    let fence = cache.commit_fence.enter_writer_slot(worker_slot);
    if let Err(error) = writeback.ensure_no_unknown() {
        return Err(abort_after_precommit_failure(native, Error::Apply(error)));
    }

    // Native holder success can publish READY and let the consumer retire its
    // occupancy before this thread resumes. Suppress automatic permit Drop
    // across every terminal; after decoding we either transfer the claim to a
    // BOUND/READY generation or explicitly drop the still-unassigned permit.
    let mut permit = std::mem::ManuallyDrop::new(permit);

    let mut bound = None;
    // The crash matrix retains its exact post-bind/pre-serialization seam by
    // selecting the legacy callback terminal only in the helper process which
    // armed that point. Oversized 32-bit records retain the direct byte arena;
    // ordinary records use the callback-free zero-copy holder terminal.
    #[cfg(test)]
    let force_callback = crate::failpoint::is_armed(crate::failpoint::Point::PreinstallBound);
    #[cfg(not(test))]
    let force_callback = false;
    #[cfg(test)]
    let force_rust_ready =
        crate::failpoint::is_armed(crate::failpoint::Point::NativeCommittedBeforeReady)
            || crate::failpoint::post_native_commit_observer_installed();
    #[cfg(not(test))]
    let force_rust_ready = false;
    let use_holder_terminal = !force_callback
        && !force_rust_ready
        && writeback::native_holder_record_supported(preflight.exact_record_bytes());

    let outcome = if use_holder_terminal {
        // SAFETY: the candidate is current, the permit owns one concurrent
        // occupancy claim, and the control borrows this queue's stable exact
        // publication/holder layout for the synchronous native terminal.
        let control = unsafe { writeback.native_ordered_holder_control() };
        unsafe {
            native.commit_trusted_native_ordered_unchecked_one_put_holder(preflight, &control)
        }
    } else if !force_callback {
        // SAFETY: this is the same direct native-ordered terminal and exact generation
        // ownership, with bytes stored in the queue arena instead of a holder.
        let control = unsafe { writeback.native_ordered_arena_control() };
        unsafe { native.commit_trusted_native_ordered_unchecked_one_put_arena(preflight, &control) }
    } else {
        let (next_bound, unhealthy) = writeback.native_ordering_words();
        // SAFETY: this test-only callback runs synchronously after native
        // assigned its timestamp and physical sequence. Adopting the
        // exact FREE generation before returning its target retains the prior
        // crash seam and the same backend-retirement ownership.
        let acquire_target = |timestamp, native_preflight, ordered_sequence| {
            debug_assert_eq!(native_preflight, preflight);
            let mut reservation =
                unsafe { permit.bind_externally_ordered(timestamp, ordered_sequence) };
            // SAFETY: `reservation` moves into `bound` before native can write
            // and remains alive through this synchronous terminal.
            let target = unsafe { reservation.native_record_target() };
            bound = Some(reservation);
            #[cfg(test)]
            crate::failpoint::hit(crate::failpoint::Point::PreinstallBound);
            Some(target)
        };
        // SAFETY: the crash helper uses the established callback contract and
        // every concurrent terminal shares the same packed order namespace.
        unsafe {
            native.commit_trusted_native_ordered_unchecked_one_put_record_target(
                preflight,
                next_bound,
                unhealthy,
                acquire_target,
            )
        }
    };

    // A partial scalar witness means native may have advanced packed order but
    // did not provide enough information to construct the matching record.
    // Do not unwind and release the detached occupancy claim across that hole.
    if !outcome.order_witness_valid() {
        std::process::abort();
    }

    if outcome.native_holder_ready() {
        if !use_holder_terminal || !outcome.is_committed() {
            // READY can already be consumer-owned. A malformed native witness
            // must terminate without unwinding and releasing its occupancy.
            std::process::abort();
        }
        let Some((_, sequence)) = outcome.accepted_order() else {
            std::process::abort();
        };
        #[cfg(test)]
        crate::failpoint::observe_post_native_holder_ready();
        #[cfg(test)]
        crate::failpoint::observe_post_native_commit();
        #[cfg(test)]
        crate::failpoint::hit(crate::failpoint::Point::NativeCommittedBeforeReady);
        // SAFETY: exact OK/OK, sealed, order, terminal kind, and bit-33 READY
        // witnesses were all checked above. This disarms occupancy before its
        // health resolver and stores caller ACK only after native's Release.
        let result = unsafe {
            permit.acknowledge_native_holder_ready_concurrent_nonblocking(sequence, fence.slot())
        };
        // SAFETY: the acknowledgement method disarmed the claim before any
        // fallible resolution. Dropping now cannot race consumer retirement.
        unsafe { std::mem::ManuallyDrop::drop(&mut permit) };
        result?;
        return Ok(());
    }
    if use_holder_terminal && outcome.is_committed() {
        // Exact holder success is required to carry the native READY witness;
        // falling back to Rust publication would hide a same-build ABI drift.
        std::process::abort();
    }

    // An exception or malformed post-order callback can return after native
    // assigned the order but before Rust acquired the cell. Adopt it now so
    // the ordinary unwritten-record path pins the exact dense obligation.
    if bound.is_none() {
        if let Some((timestamp, sequence)) = outcome.accepted_order() {
            bound = Some(if !force_callback {
                // SAFETY: a nonzero order returned by the direct terminal also
                // proves native Release-published this exact BOUND generation.
                unsafe { permit.adopt_externally_bound(timestamp, sequence) }
            } else {
                // SAFETY: a callback-terminal exception can expose its order
                // before the Rust binder ran; acquire that FREE generation now.
                unsafe { permit.bind_externally_ordered(timestamp, sequence) }
            });
        }
    }

    // SAFETY: accepted outcomes transferred the occupancy right into `bound`;
    // preaccept failures still own it and release it exactly once here.
    unsafe { std::mem::ManuallyDrop::drop(&mut permit) };

    if outcome.is_committed() {
        let reservation = bound
            .as_mut()
            .expect("trusted native success must retain its bound arena target");
        #[cfg(test)]
        crate::failpoint::observe_post_native_commit();
        #[cfg(test)]
        crate::failpoint::hit(crate::failpoint::Point::NativeCommittedBeforeReady);
        // SAFETY: `is_committed` proves the exact sealed-holder witness,
        // definite visibility, and successful cleanup. Publish BOUND -> READY.
        debug_assert!(!use_holder_terminal);
        unsafe { reservation.publish_completed_concurrent_nonblocking(fence.slot())? };
        return Ok(());
    }

    // Anomalous/unsuccessful returns retain the complete established fail-stop
    // protocol. Only this cold branch pays for decoding the public report.
    let record_report = outcome.into_report();
    enforce_record_completion_contract(&record_report);
    let report = record_report.commit;
    assert_eq!(
        record_report.record_bound,
        bound.is_some(),
        "native and queue record-binding outcomes diverged"
    );
    #[cfg(test)]
    crate::failpoint::observe_post_native_commit();
    #[cfg(test)]
    if bound.is_some() {
        crate::failpoint::hit(crate::failpoint::Point::NativeCommittedBeforeReady);
    }

    if let Some(reservation) = bound.as_mut() {
        if !record_report.record_written {
            return Err(finish_unwritten_native_arena(reservation, record_report));
        }
        return match report.disposition {
            CommitDisposition::Committed => {
                // SAFETY: report validation plus `record_written` proves the
                // direct holder or callback arena target is complete.
                let sequence = if use_holder_terminal {
                    unsafe {
                        reservation.publish_holder_completed_concurrent_nonblocking(fence.slot())?
                    }
                } else {
                    unsafe { reservation.publish_completed()? }
                };
                match report.cleanup {
                    Ok(()) => Ok(()),
                    Err(source) => Err(Error::CommittedButCleanupFailed { sequence, source }),
                }
            }
            CommitDisposition::Aborted(source) | CommitDisposition::Unknown(source) => {
                // SAFETY: the completion witness makes the holder/bytes
                // replayable, but uncertain visibility permanently pins its
                // sequence.
                let sequence = if use_holder_terminal {
                    unsafe { reservation.pin_holder_completed_unknown()? }
                } else {
                    unsafe { reservation.pin_completed_unknown()? }
                };
                Err(Error::UnknownCommitOutcome {
                    sequence,
                    source,
                    cleanup: report.cleanup.err(),
                })
            }
        };
    }

    match report.disposition {
        CommitDisposition::Committed => {
            panic!("native write commit succeeded without invoking its pre-install hook")
        }
        CommitDisposition::Aborted(abort) | CommitDisposition::Unknown(abort) => {
            match report.cleanup {
                Ok(()) => Err(Error::Native(abort)),
                Err(cleanup) => Err(Error::AbortCleanupFailed { abort, cleanup }),
            }
        }
    }
}

/// Complete the callback-free, preselected one-Put SPSC terminal.
///
/// The thread-affine mutable producer lease excludes every other foreground
/// terminal for this LocalDb. That lets Rust select the exact dense sequence
/// and queue-owned native holder before entering native code. The future
/// generation stays invisible until native returns a nonzero accepted Mako
/// timestamp; an OCC loser therefore consumes no log sequence. Native moves
/// STO's staged value allocation into the holder after install, and Rust
/// Release-publishes only the scalar dense tail.
#[allow(unsafe_code)]
#[inline(always)]
fn finish_trusted_one_put_holder_single<'cache, 'db, B: Blobs + 'static>(
    writeback: &'cache Writeback<Arc<B>>,
    native: mako_engine::Transaction<'db>,
    exact_record_bytes: NonZeroU32,
    producer: &'cache writeback::SingleProducerState,
    sequence: NonZeroU64,
    per_worker: bool,
) -> Result<(), Error> {
    #[cfg(test)]
    crate::failpoint::hit(crate::failpoint::Point::DetachedPrepared);

    // SAFETY: this terminal is reachable only for a queue and lease created in
    // single-producer mode; the cache outlives the synchronous native call.
    // SAFETY: the thread-affine producer lease owns this future dense
    // generation and the corresponding masked holder through the synchronous
    // consuming terminal. No consumer can view it before Rust's later Release.
    let outcome = unsafe {
        if per_worker {
            native.commit_trusted_preselected_per_worker_unchecked_one_put_holder_bytes(
                exact_record_bytes,
                producer.fused_holder_control(),
                sequence,
            )
        } else {
            native.commit_trusted_preselected_single_producer_unchecked_one_put_holder_bytes(
                exact_record_bytes,
                writeback.native_holder_pool_single_unchecked(),
                sequence,
            )
        }
    };

    if let Some(timestamp) = outcome.committed_timestamp() {
        // SAFETY: the fused compact predicate proves definite visibility,
        // successful cleanup, and a sealed exact-generation holder. Ordinary
        // publication consists only of the producer cursor and ACK stores.
        if unsafe { writeback.try_publish_native_holder_single(producer, sequence) } {
            return Ok(());
        }
        return finish_committed_native_holder_cold(
            writeback,
            sequence,
            timestamp,
            exact_record_bytes,
        );
    }

    finish_holder_outcome_cold(writeback, producer, sequence, exact_record_bytes, outcome)
}

/// Attach a definitely committed holder behind a concurrently latched
/// fail-stop barrier. The producer cursor was already advanced by the compact
/// publication attempt, so this path must not make the generation reusable.
#[cold]
#[inline(never)]
fn finish_committed_native_holder_cold<B: Blobs + 'static>(
    writeback: &Writeback<B>,
    sequence: NonZeroU64,
    timestamp: MakoTimestamp,
    exact_record_bytes: NonZeroU32,
) -> Result<(), Error> {
    writeback.publish_native_holder_single_cold(sequence, timestamp, exact_record_bytes)?;
    Ok(())
}

/// Decode a non-success holder outcome entirely off the ordinary ACK path.
#[cold]
#[inline(never)]
fn finish_holder_outcome_cold<B: Blobs + 'static>(
    writeback: &Writeback<B>,
    producer: &writeback::SingleProducerState,
    sequence: NonZeroU64,
    exact_record_bytes: NonZeroU32,
    outcome: mako_engine::TrustedPreselectedUncheckedOnePutHolderOutcome,
) -> Result<(), Error> {
    let Some(timestamp) = outcome.accepted_timestamp() else {
        let report = outcome.into_report();
        enforce_unaccepted_holder_completion_contract(&report);
        return match report.commit.disposition {
            CommitDisposition::Committed => unreachable!(
                "a valid unaccepted holder outcome cannot report a committed transaction"
            ),
            CommitDisposition::Aborted(abort) | CommitDisposition::Unknown(abort) => {
                match report.commit.cleanup {
                    Ok(()) => Err(Error::Native(abort)),
                    Err(cleanup) => Err(Error::AbortCleanupFailed { abort, cleanup }),
                }
            }
        };
    };

    finish_anomalous_accepted_holder(
        writeback,
        producer,
        sequence,
        exact_record_bytes,
        timestamp,
        outcome.holder_sealed(),
        || outcome.into_report(),
    )
}

/// Pin every accepted holder result outside the exact ordinary-success word
/// before decoding it into richer status types.
///
/// The pin deliberately precedes `decode`. Besides keeping malformed ABI words
/// fail-closed, this ordering means a panic in a future cold decoder cannot
/// unwind before the retained sequence is made visible and silently make an
/// already accepted sequence reusable.
#[cold]
#[inline(never)]
#[allow(unsafe_code)]
fn finish_anomalous_accepted_holder<B, F>(
    writeback: &Writeback<B>,
    producer: &writeback::SingleProducerState,
    sequence: NonZeroU64,
    exact_record_bytes: NonZeroU32,
    timestamp: MakoTimestamp,
    sealed: bool,
    decode: F,
) -> Result<(), Error>
where
    B: Blobs + 'static,
    F: FnOnce() -> mako_engine::CommitHolderReport,
{
    let sequence = if sealed {
        // SAFETY: `sealed` is the raw native completion witness paired with the
        // accepted timestamp. Even when the remaining terminal word is corrupt,
        // these two scalars cover the exact preselected holder generation.
        unsafe {
            writeback.pin_native_holder_sealed_unknown_single(
                producer,
                sequence,
                timestamp,
                exact_record_bytes,
            )?
        }
    } else {
        writeback.pin_native_holder_unsealed_unknown_single(producer, sequence)?
    };

    let report = decode();
    let cleanup = report.commit.cleanup.err();
    let source = match report.commit.disposition {
        // Exact OK/OK + accepted + sealed returned through the fast branch
        // above. Any other word decoded as Committed is an ABI contradiction;
        // the sequence is already pinned, so surface a typed unknown instead
        // of risking later reuse.
        CommitDisposition::Committed => LocalError::Internal,
        CommitDisposition::Aborted(source) | CommitDisposition::Unknown(source) => source,
    };
    Err(Error::UnknownCommitOutcome {
        sequence,
        source,
        cleanup,
    })
}

/// Complete the older direct-arena one-Put SPSC terminal used when native
/// holder deferral is unavailable.
#[allow(unsafe_code)]
fn finish_trusted_one_put_arena_single<'cache, 'db, B: Blobs + 'static>(
    cache: &'cache Cache<B>,
    native: mako_engine::Transaction<'db>,
    preflight: mako_engine::CommitRecordPreflight,
    mut permit: writeback::NativeArenaPermit<'cache, B>,
) -> Result<(), Error> {
    #[cfg(test)]
    crate::failpoint::hit(crate::failpoint::Point::DetachedPrepared);

    if let Err(error) = cache.writeback.ensure_no_unknown() {
        return Err(abort_after_precommit_failure(native, Error::Apply(error)));
    }

    // SAFETY: the mutable, thread-affine lease which selected this code path
    // remains borrowed through the consuming terminal and queue resolution.
    // It protects this exact FREE turn and arena extent from every other
    // foreground transaction.
    let preselected = unsafe { permit.preselected_record_target() };
    #[cfg(test)]
    // The old callback path reached this rendezvous after publishing BOUND but
    // still before install. Callback-free SPSC deliberately keeps BOUND
    // invisible until native acceptance; selecting the irrevocable target is
    // its corresponding pre-native crash boundary.
    crate::failpoint::hit(crate::failpoint::Point::PreinstallBound);
    // SAFETY: `preselected` is the exact target advertised by `preflight`; the
    // unique producer lease provides the whole-call exclusion required by the
    // callback-free native ABI.
    let outcome = unsafe {
        native.commit_trusted_preselected_single_producer_unchecked_one_put_record_target(
            preflight,
            preselected.native(),
        )
    };

    let Some(timestamp) = outcome.accepted_timestamp() else {
        // No accepted timestamp means native never crossed the point after
        // which this exact invisible turn must become part of the dense log.
        // Decode before dropping the permit so malformed same-build ABI state
        // triggers the process-level contract guard rather than reusing it.
        let record_report = outcome.into_report();
        enforce_record_completion_contract(&record_report);
        assert!(!record_report.record_bound);
        let report = record_report.commit;
        return match report.disposition {
            CommitDisposition::Committed => {
                panic!("native write commit succeeded without accepting its preselected record")
            }
            CommitDisposition::Aborted(abort) | CommitDisposition::Unknown(abort) => {
                match report.cleanup {
                    Ok(()) => Err(Error::Native(abort)),
                    Err(cleanup) => Err(Error::AbortCleanupFailed { abort, cleanup }),
                }
            }
        };
    };

    if outcome.is_committed() {
        #[cfg(not(test))]
        {
            // SAFETY: the compact success witness proves complete target
            // initialization, definite native visibility, successful cleanup,
            // and the same accepted timestamp. The production SPSC path can
            // publish FREE directly to READY without materializing a bound
            // reservation or an intermediate turn.
            unsafe { permit.publish_preselected_committed_after_native(timestamp, preselected)? };
            return Ok(());
        }
        #[cfg(test)]
        {
            // Keep deterministic crash/response observers between BOUND and
            // READY in test builds. Production contains neither observer and
            // uses the direct publication above.
            // SAFETY: `timestamp` is native's acceptance witness for this
            // exact target and the unique lease remains live.
            let mut reservation =
                unsafe { permit.bind_preselected_after_native(timestamp, preselected) };
            crate::failpoint::observe_post_native_commit();
            crate::failpoint::hit(crate::failpoint::Point::NativeCommittedBeforeReady);
            // SAFETY: established by the compact committed witness.
            unsafe { reservation.publish_completed()? };
            return Ok(());
        }
    }

    // Only anomalous/unsuccessful accepted outcomes pay for a materialized
    // bound reservation and the full decode. Every path below either publishes
    // a known commit or permanently pins the exact dense sequence.
    // SAFETY: every accepted timestamp must bind its exact preselected turn
    // before decoding or executing any other fallible operation.
    let mut reservation = unsafe { permit.bind_preselected_after_native(timestamp, preselected) };
    #[cfg(test)]
    crate::failpoint::observe_post_native_commit();
    #[cfg(test)]
    crate::failpoint::hit(crate::failpoint::Point::NativeCommittedBeforeReady);
    let record_report = outcome.into_report();
    enforce_record_completion_contract(&record_report);
    assert!(record_report.record_bound);
    if !record_report.record_written {
        return Err(finish_unwritten_native_arena(
            &mut reservation,
            record_report,
        ));
    }

    let report = record_report.commit;
    match report.disposition {
        CommitDisposition::Committed => {
            // SAFETY: the validated completion witness covers the full exact
            // target even though terminal cleanup returned an error.
            let sequence = unsafe { reservation.publish_completed()? };
            match report.cleanup {
                Ok(()) => Ok(()),
                Err(source) => Err(Error::CommittedButCleanupFailed { sequence, source }),
            }
        }
        CommitDisposition::Aborted(source) | CommitDisposition::Unknown(source) => {
            // SAFETY: bytes are complete but visibility is not definitely
            // committed, so retaining them behind a permanent pin is sound.
            let sequence = unsafe { reservation.pin_completed_unknown()? };
            Err(Error::UnknownCommitOutcome {
                sequence,
                source,
                cleanup: report.cleanup.err(),
            })
        }
    }
}

fn finish_read_only(native: mako_engine::Transaction<'_>) -> Result<(), Error> {
    let report = native.commit_report();
    match report.disposition {
        CommitDisposition::Committed => report.cleanup.map_err(Error::Native),
        CommitDisposition::Aborted(abort) | CommitDisposition::Unknown(abort) => {
            match report.cleanup {
                Ok(()) => Err(Error::Native(abort)),
                Err(cleanup) => Err(Error::AbortCleanupFailed { abort, cleanup }),
            }
        }
    }
}

/// Abort an active native transaction after Rust-side preparation failed.
///
/// Returning the preparation error is correct only when native cleanup is
/// known complete. A cleanup failure quarantines the worker and is the more
/// severe result, matching mako-local's own fail-closed preflight behavior.
fn abort_after_precommit_failure(
    native: mako_engine::Transaction<'_>,
    preparation: Error,
) -> Error {
    match native.abort() {
        Ok(()) => preparation,
        Err(cleanup) => Error::Native(cleanup),
    }
}

#[cold]
fn enforce_record_completion_contract(report: &mako_engine::CommitRecordReport) {
    if !report.completion_contract_valid && !report.record_bound {
        // Native consumed the transaction handle but returned a malformed
        // terminal result without invoking the only callback that could
        // establish serialization order and a durability slot. There is no
        // sound sequence to pin and no safe way to admit later work. This is
        // ABI corruption, not a recoverable commit error; terminate even in
        // panic-unwind builds.
        std::process::abort();
    }
}

#[cold]
fn enforce_unaccepted_holder_completion_contract(report: &mako_engine::CommitHolderReport) {
    if !report.completion_contract_valid
        || report.holder_bound
        || report.holder_sealed
        || matches!(report.commit.disposition, CommitDisposition::Committed)
    {
        // A valid zero-timestamp result is a definite pre-acceptance abort and
        // leaves the retained holder generation FREE. Anything else could hide
        // a visible write for which Rust has no trusted serialization timestamp.
        // Continuing would let Drop reuse the same dense sequence and holder,
        // so terminate instead of turning ABI corruption into a durability gap.
        std::process::abort();
    }
}

fn finish_unwritten_bound<B: Blobs>(
    reservation: &mut writeback::BoundReservation<'_, B>,
    record_report: mako_engine::CommitRecordReport,
) -> Error {
    assert!(record_report.record_bound);
    assert!(!record_report.record_written);
    let sequence = reservation.sequence();
    // Resolve in place so the normal callback-owned Option never needs to move
    // the reservation merely to perform its fail-closed transition. Drop is a
    // defense-in-depth retry if this internal transition unexpectedly fails.
    let _ = reservation.pin_unknown();
    let report = record_report.commit;
    match report.disposition {
        CommitDisposition::Aborted(abort)
            if record_report.completion_contract_valid
                && abort == LocalError::CommitHookRejected =>
        {
            Error::BoundRecordUnwritten {
                sequence,
                abort,
                cleanup: report.cleanup.err(),
            }
        }
        CommitDisposition::Committed => Error::UnknownCommitOutcome {
            sequence,
            source: LocalError::Internal,
            cleanup: report.cleanup.err(),
        },
        CommitDisposition::Aborted(source) | CommitDisposition::Unknown(source) => {
            Error::UnknownCommitOutcome {
                sequence,
                source,
                cleanup: report.cleanup.err(),
            }
        }
    }
}

fn finish_unwritten_native_arena<B: Blobs>(
    reservation: &mut writeback::NativeArenaBoundReservation<'_, B>,
    record_report: mako_engine::CommitRecordReport,
) -> Error {
    assert!(record_report.record_bound);
    assert!(!record_report.record_written);
    let sequence = reservation.sequence();
    let _ = reservation.pin_unwritten_unknown();
    let report = record_report.commit;
    match report.disposition {
        CommitDisposition::Aborted(abort)
            if record_report.completion_contract_valid
                && abort == LocalError::CommitHookRejected =>
        {
            Error::BoundRecordUnwritten {
                sequence,
                abort,
                cleanup: report.cleanup.err(),
            }
        }
        CommitDisposition::Committed => Error::UnknownCommitOutcome {
            sequence,
            source: LocalError::Internal,
            cleanup: report.cleanup.err(),
        },
        CommitDisposition::Aborted(source) | CommitDisposition::Unknown(source) => {
            Error::UnknownCommitOutcome {
                sequence,
                source,
                cleanup: report.cleanup.err(),
            }
        }
    }
}

fn validate_gc_options(options: CacheOptions) -> Result<(), Error> {
    if options.gc_interval.is_zero()
        || u64::try_from(options.gc_interval.as_micros()).is_err()
        || u64::try_from(options.log_retention.as_micros()).is_err()
        || std::time::Instant::now()
            .checked_add(options.gc_interval)
            .is_none()
    {
        return Err(Error::InvalidGcOptions);
    }
    Ok(())
}

#[cfg(test)]
thread_local! {
    static RECOVERY_REPLAY_AUDIT: std::cell::RefCell<Option<Vec<u64>>> = const {
        std::cell::RefCell::new(None)
    };
}

#[cfg(test)]
fn begin_replay_audit() {
    RECOVERY_REPLAY_AUDIT.with(|audit| {
        let previous = audit.replace(Some(Vec::new()));
        assert!(previous.is_none(), "nested recovery replay audit");
    });
}

#[cfg(test)]
fn record_replayed_sequence(sequence: CommitSeq) {
    RECOVERY_REPLAY_AUDIT.with(|audit| {
        if let Some(sequences) = audit.borrow_mut().as_mut() {
            sequences.push(sequence.get());
        }
    });
}

#[cfg(test)]
fn finish_replay_audit() -> Vec<u64> {
    RECOVERY_REPLAY_AUDIT.with(|audit| {
        audit
            .replace(None)
            .expect("recovery replay audit was not active")
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn test_timestamp(logical: u32) -> MakoTimestamp {
        MakoTimestamp::new(1_700_000_000_000_000, logical, 1).unwrap()
    }

    #[test]
    fn commit_fence_read_only_closer_drains_an_enrolled_writer() {
        use std::sync::mpsc::{channel, TryRecvError};
        use std::time::Duration;

        let fence = Arc::new(CommitFence::new());
        let payload = Arc::new(AtomicUsize::new(0));
        let validation_next = Arc::new(AtomicUsize::new(0));
        let slot = CommitFence::current_thread_slot();
        let writer = fence.enter_writer_slot(slot);
        validation_next.fetch_add(1, Ordering::Release);
        payload.store(17, Ordering::Relaxed);

        let reader_fence = Arc::clone(&fence);
        let reader_payload = Arc::clone(&payload);
        let reader_validation_next = Arc::clone(&validation_next);
        let (cut_tx, cut_rx) = channel();
        let (entered_tx, entered_rx) = channel();
        let reader = std::thread::spawn(move || {
            reader_fence.close_for_read_only(|| {
                reader_validation_next.fetch_add(0, Ordering::Acquire);
                cut_tx.send(()).unwrap();
            });
            entered_tx
                .send(reader_payload.load(Ordering::Relaxed))
                .unwrap();
        });

        cut_rx
            .recv_timeout(Duration::from_secs(5))
            .expect("read-only validation cut did not run");
        assert_eq!(entered_rx.try_recv(), Err(TryRecvError::Empty));

        drop(writer);
        assert_eq!(entered_rx.recv_timeout(Duration::from_secs(5)), Ok(17));
        reader.join().unwrap();
    }

    #[test]
    fn commit_fence_readers_take_independent_cuts_and_drain_the_same_writer() {
        use std::sync::mpsc::{channel, TryRecvError};
        use std::time::Duration;

        let fence = Arc::new(CommitFence::new());
        let order = Arc::new(AtomicUsize::new(0));
        let payload = Arc::new(AtomicUsize::new(0));
        let slot = CommitFence::current_thread_slot();
        let writer = fence.enter_writer_slot(slot);
        order.fetch_add(1, Ordering::Release);
        payload.store(17, Ordering::Relaxed);
        let (cuts_tx, cuts_rx) = channel();
        let (done_tx, done_rx) = channel();
        let mut releases = Vec::new();
        let mut readers = Vec::new();
        for _ in 0..2 {
            let fence = Arc::clone(&fence);
            let order = Arc::clone(&order);
            let payload = Arc::clone(&payload);
            let cuts_tx = cuts_tx.clone();
            let done_tx = done_tx.clone();
            let (release_tx, release_rx) = channel();
            releases.push(release_tx);
            readers.push(std::thread::spawn(move || {
                fence.close_for_read_only(|| {
                    order.fetch_add(0, Ordering::Acquire);
                    cuts_tx.send(()).unwrap();
                    release_rx.recv_timeout(Duration::from_secs(20)).unwrap();
                });
                done_tx.send(payload.load(Ordering::Relaxed)).unwrap();
            }));
        }
        let first_cut = cuts_rx.recv_timeout(Duration::from_secs(5)).is_ok();
        let second_cut = cuts_rx.recv_timeout(Duration::from_secs(5)).is_ok();
        assert_eq!(done_rx.try_recv(), Err(TryRecvError::Empty));
        // Always release and join both children before asserting the overlap.
        // Restoring the old mutex must fail this test without stranding a thread.
        for release in releases {
            let _ = release.send(());
        }
        drop(writer);
        for reader in readers {
            reader.join().unwrap();
        }
        assert_eq!(done_rx.recv_timeout(Duration::from_secs(5)), Ok(17));
        assert_eq!(done_rx.recv_timeout(Duration::from_secs(5)), Ok(17));
        assert!(first_cut && second_cut, "read-only cuts were serialized");
    }

    #[test]
    fn commit_fence_writer_after_validation_cut_is_not_blocked() {
        let fence = CommitFence::new();
        let validation_next = AtomicUsize::new(0);
        fence.close_for_read_only(|| {
            validation_next.fetch_add(0, Ordering::Acquire);
        });

        let slot = CommitFence::current_thread_slot();
        let writer = fence.enter_writer_slot(slot);
        validation_next.fetch_add(1, Ordering::Release);
        assert!(
            fence.writers[slot].generation.load(Ordering::Acquire) & 1 != 0,
            "a post-cut writer should enter without waiting for the reader"
        );
        drop(writer);
    }

    #[test]
    fn commit_fence_exact_generation_does_not_bridge_worker_reuse() {
        use std::sync::mpsc::{channel, sync_channel};
        use std::time::Duration;

        let fence = Arc::new(CommitFence::new());
        let validation_next = Arc::new(AtomicUsize::new(0));
        let slot = CommitFence::current_thread_slot();
        let first = fence.enter_writer_slot(slot);
        validation_next.fetch_add(1, Ordering::Release);

        let reader_fence = Arc::clone(&fence);
        let reader_validation_next = Arc::clone(&validation_next);
        let (observed_tx, observed_rx) = channel();
        let (reused_tx, reused_rx) = sync_channel(0);
        let (drained_tx, drained_rx) = channel();
        let reader = std::thread::spawn(move || {
            reader_validation_next.fetch_add(0, Ordering::Acquire);
            let observed = reader_fence.writers[slot]
                .generation
                .load(Ordering::Acquire);
            assert_eq!(observed & 1, 1);
            observed_tx.send(observed).unwrap();
            reused_rx.recv().unwrap();
            let mut spins = 0;
            reader_fence.writers[slot].drain_observed(observed, &mut spins);
            drained_tx.send(()).unwrap();
        });

        let first_generation = observed_rx
            .recv_timeout(Duration::from_secs(5))
            .expect("reader did not observe the first active generation");
        drop(first);
        let second = fence.enter_writer_slot(slot);
        validation_next.fetch_add(1, Ordering::Release);
        assert_ne!(
            fence.writers[slot].generation.load(Ordering::Acquire),
            first_generation
        );
        reused_tx.send(()).unwrap();
        drained_rx
            .recv_timeout(Duration::from_secs(5))
            .expect("the first generation wait bridged into its successor");

        // The reader returned while the deliberately post-cut successor still
        // owned the same worker slot.
        assert_eq!(
            fence.writers[slot].generation.load(Ordering::Acquire) & 1,
            1
        );
        drop(second);
        reader.join().unwrap();
    }

    #[test]
    fn commit_fence_scan_bound_includes_registration_completed_inside_cut() {
        let fence = CommitFence::new();
        let allocated = Cell::new(None);
        let order = Arc::new(AtomicUsize::new(0));
        let bound = fence.read_only_scan_bound(|| {
            let writer_order = Arc::clone(&order);
            let slot = std::thread::spawn(move || {
                let slot = CommitFence::current_thread_slot();
                writer_order.fetch_add(1, Ordering::Release);
                slot
            })
            .join()
            .unwrap();
            allocated.set(Some(slot));
            order.fetch_add(0, Ordering::Acquire);
        });
        // This checks the production helper's call order deterministically.
        // The Loom models separately check weak-memory publication without
        // depending on the test's join synchronization.
        assert!(
            bound > allocated.get().unwrap(),
            "the scan bound omitted a registration completed before the cut"
        );
        assert!(bound <= fence.writers.len());
    }

    #[test]
    fn unbound_native_record_contract_violation_aborts_process() {
        const ROLE: &str = "MAKO_CACHE_UNBOUND_RECORD_CONTRACT_VIOLATION_ROLE";
        if std::env::var_os(ROLE).is_some() {
            enforce_record_completion_contract(&mako_engine::CommitRecordReport {
                commit: mako_engine::CommitReport {
                    disposition: CommitDisposition::Unknown(LocalError::Internal),
                    cleanup: Err(LocalError::Internal),
                },
                completion_contract_valid: false,
                record_bound: false,
                record_written: false,
            });
            unreachable!("the uncovered native completion must fail-stop");
        }

        let status = std::process::Command::new(std::env::current_exe().unwrap())
            .arg("--exact")
            .arg("tests::unbound_native_record_contract_violation_aborts_process")
            .env(ROLE, "1")
            .status()
            .expect("run fail-stop subprocess");
        assert!(!status.success(), "contract corruption process survived");
        #[cfg(unix)]
        {
            use std::os::unix::process::ExitStatusExt;
            assert_eq!(status.signal(), Some(6), "expected SIGABRT");
        }
    }

    #[test]
    fn unaccepted_native_holder_contract_violation_aborts_process() {
        const ROLE: &str = "MAKO_CACHE_UNACCEPTED_HOLDER_CONTRACT_VIOLATION_ROLE";
        if std::env::var_os(ROLE).is_some() {
            enforce_unaccepted_holder_completion_contract(&mako_engine::CommitHolderReport {
                commit: mako_engine::CommitReport {
                    disposition: CommitDisposition::Unknown(LocalError::Internal),
                    cleanup: Err(LocalError::Internal),
                },
                completion_contract_valid: false,
                holder_bound: false,
                holder_sealed: false,
            });
            unreachable!("the uncovered native holder completion must fail-stop");
        }

        let status = std::process::Command::new(std::env::current_exe().unwrap())
            .arg("--exact")
            .arg("tests::unaccepted_native_holder_contract_violation_aborts_process")
            .env(ROLE, "1")
            .status()
            .expect("run holder fail-stop subprocess");
        assert!(!status.success(), "holder contract corruption survived");
        #[cfg(unix)]
        {
            use std::os::unix::process::ExitStatusExt;
            assert_eq!(status.signal(), Some(6), "expected SIGABRT");
        }
    }

    #[cfg(have_mako)]
    #[test]
    fn anomalous_accepted_holder_pins_before_cold_decode() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let mut config = WritebackConfig::default();
        config.capacity = 1;
        let writeback = Writeback::new_with_watermark_mode(
            Arc::new(MemBlobs::new()),
            AppliedWatermark::default(),
            config,
            true,
        )
        .unwrap();
        let producer = writeback.single_producer_state();
        let sequence = writeback
            .reserve_native_holder_single(&producer, NonZeroU32::new(64).unwrap())
            .unwrap();
        let timestamp = test_timestamp(17);

        let error = finish_anomalous_accepted_holder(
            &writeback,
            &producer,
            sequence,
            NonZeroU32::new(64).unwrap(),
            timestamp,
            false,
            || {
                assert!(matches!(
                    writeback.ensure_no_unknown(),
                    Err(ApplyError::UnknownOutcome { sequence }) if sequence.get() == 1
                ));
                mako_engine::CommitHolderReport {
                    commit: mako_engine::CommitReport {
                        disposition: CommitDisposition::Unknown(LocalError::Internal),
                        cleanup: Err(LocalError::Internal),
                    },
                    completion_contract_valid: false,
                    holder_bound: true,
                    holder_sealed: false,
                }
            },
        )
        .unwrap_err();
        assert!(matches!(
            error,
            Error::UnknownCommitOutcome {
                sequence,
                source: LocalError::Internal,
                cleanup: Some(LocalError::Internal),
            } if sequence.get() == 1
        ));
        assert_eq!(writeback.highest_acknowledged(), 0);
        assert!(matches!(
            writeback.ensure_no_unknown(),
            Err(ApplyError::UnknownOutcome { sequence }) if sequence.get() == 1
        ));
    }

    #[cfg(have_mako)]
    #[test]
    fn anomalous_accepted_holder_stays_pinned_if_decoder_panics() {
        use std::panic::{catch_unwind, AssertUnwindSafe};
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let writeback = Writeback::new_with_watermark_mode(
            Arc::new(MemBlobs::new()),
            AppliedWatermark::default(),
            WritebackConfig::default(),
            true,
        )
        .unwrap();
        let producer = writeback.single_producer_state();
        let sequence = writeback
            .reserve_native_holder_single(&producer, NonZeroU32::new(64).unwrap())
            .unwrap();
        let timestamp = test_timestamp(18);

        let panic = catch_unwind(AssertUnwindSafe(|| {
            let _ = finish_anomalous_accepted_holder(
                &writeback,
                &producer,
                sequence,
                NonZeroU32::new(64).unwrap(),
                timestamp,
                false,
                || {
                    assert!(matches!(
                        writeback.ensure_no_unknown(),
                        Err(ApplyError::UnknownOutcome { sequence }) if sequence.get() == 1
                    ));
                    panic!("synthetic cold decoder failure");
                },
            );
        }));
        assert!(panic.is_err());
        assert_eq!(writeback.highest_acknowledged(), 0);
        assert!(matches!(
            writeback.ensure_no_unknown(),
            Err(ApplyError::UnknownOutcome { sequence }) if sequence.get() == 1
        ));
    }

    #[test]
    fn bound_unwritten_completion_is_typed_and_pins_its_dense_slot() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        fn reservation<'a>(
            writeback: &'a Writeback<Arc<MemBlobs>>,
        ) -> writeback::BoundReservation<'a, Arc<MemBlobs>> {
            writeback
                .reserve(vec![Mutation::Put {
                    table_id: DEFAULT_TABLE_ID,
                    key: b"unwritten".to_vec(),
                    value: b"never-installed".to_vec(),
                }])
                .unwrap()
                .bind(test_timestamp(1))
                .unwrap()
        }

        let writeback =
            Writeback::new(Arc::new(MemBlobs::new()), 0, WritebackConfig::default()).unwrap();
        let error = finish_unwritten_bound(
            &mut reservation(&writeback),
            mako_engine::CommitRecordReport {
                commit: mako_engine::CommitReport {
                    disposition: CommitDisposition::Aborted(LocalError::CommitHookRejected),
                    cleanup: Ok(()),
                },
                completion_contract_valid: true,
                record_bound: true,
                record_written: false,
            },
        );
        assert!(matches!(
            error,
            Error::BoundRecordUnwritten {
                sequence,
                abort: LocalError::CommitHookRejected,
                cleanup: None,
            } if sequence.get() == 1
        ));
        assert!(matches!(
            writeback.ensure_no_unknown(),
            Err(ApplyError::UnknownOutcome { sequence }) if sequence.get() == 1
        ));

        let malformed =
            Writeback::new(Arc::new(MemBlobs::new()), 0, WritebackConfig::default()).unwrap();
        let error = finish_unwritten_bound(
            &mut reservation(&malformed),
            mako_engine::CommitRecordReport {
                commit: mako_engine::CommitReport {
                    disposition: CommitDisposition::Unknown(LocalError::Internal),
                    cleanup: Err(LocalError::Internal),
                },
                completion_contract_valid: false,
                record_bound: true,
                record_written: false,
            },
        );
        assert!(matches!(
            error,
            Error::UnknownCommitOutcome {
                sequence,
                source: LocalError::Internal,
                cleanup: Some(LocalError::Internal),
            } if sequence.get() == 1
        ));
        assert!(matches!(
            malformed.ensure_no_unknown(),
            Err(ApplyError::UnknownOutcome { sequence }) if sequence.get() == 1
        ));

        // Defense in depth: even if a future wrapper accidentally marks this
        // impossible post-bind conflict shape as contract-valid, the cache
        // must not tell callers it was a retryable definite abort.
        let impossible_conflict =
            Writeback::new(Arc::new(MemBlobs::new()), 0, WritebackConfig::default()).unwrap();
        let error = finish_unwritten_bound(
            &mut reservation(&impossible_conflict),
            mako_engine::CommitRecordReport {
                commit: mako_engine::CommitReport {
                    disposition: CommitDisposition::Aborted(LocalError::Conflict),
                    cleanup: Ok(()),
                },
                completion_contract_valid: true,
                record_bound: true,
                record_written: false,
            },
        );
        assert!(matches!(
            error,
            Error::UnknownCommitOutcome {
                sequence,
                source: LocalError::Conflict,
                cleanup: None,
            } if sequence.get() == 1
        ));
        assert!(matches!(
            impossible_conflict.ensure_no_unknown(),
            Err(ApplyError::UnknownOutcome { sequence }) if sequence.get() == 1
        ));
    }

    #[cfg(have_mako)]
    fn test_record(sequence: u64, timestamp: u32, key: &[u8]) -> CommitRecord {
        test_record_with_mutations(
            sequence,
            timestamp,
            vec![Mutation::Put {
                table_id: DEFAULT_TABLE_ID,
                key: key.to_vec(),
                value: b"value".to_vec(),
            }],
        )
    }

    #[cfg(have_mako)]
    fn test_record_with_mutations(
        sequence: u64,
        timestamp: u32,
        mutations: Vec<Mutation>,
    ) -> CommitRecord {
        crate::record::PreparedCommitRecord::prepare(
            mutations,
            CacheOptions::default().writeback.max_record_bytes,
        )
        .unwrap()
        .bind(
            CommitSeq::new(sequence).expect("test sequence is nonzero"),
            test_timestamp(timestamp),
        )
        .finalize()
    }

    #[cfg(have_mako)]
    fn install_test_record(backend: &impl Blobs, record: &CommitRecord) {
        // Deliberately permit malformed history (gaps/reversed lane HLCs) so
        // recovery tests can check rejection independently of the coordinator.
        let tag = checkpoint::lane_tag(record.sequence()).unwrap();
        let lane_key = checkpoint::lane_key(tag);
        let mut lane = backend
            .get(&lane_key)
            .unwrap()
            .map(|bytes| checkpoint::LaneMetadata::decode(&bytes).unwrap())
            .unwrap_or_default();
        let (_, position) = record::split_log_sequence(record.sequence()).unwrap();
        lane.applied = lane.applied.max(position);
        lane.max_timestamp = Some(lane.max_timestamp.map_or(record.mako_timestamp(), |old| {
            old.max(record.mako_timestamp())
        }));
        lane.retained_bytes += (record.log_key().len() + record.encoded().len()) as u64;
        let mut writes = vec![
            (
                checkpoint::FORMAT_KEY.to_vec(),
                checkpoint::encode_format().unwrap(),
            ),
            (record.log_key().to_vec(), record.encoded().to_vec()),
            (lane_key, lane.encode().unwrap()),
        ];
        for (mutation, data_key) in record.mutations().iter().zip(record.data_keys()) {
            let old = backend.get(data_key).unwrap();
            if old
                .as_deref()
                .map(checkpoint::decode_row)
                .transpose()
                .unwrap()
                .is_some_and(|old| old.timestamp > record.mako_timestamp())
            {
                continue;
            }
            let value = match mutation {
                Mutation::Put { value, .. } => Some(value.as_slice()),
                Mutation::Delete { .. } => None,
            };
            writes.push((
                data_key.clone(),
                checkpoint::encode_row(record.mako_timestamp(), record.sequence(), value).unwrap(),
            ));
        }
        let ops: Vec<_> = writes
            .iter()
            .map(|(key, val)| mrx_core::BlobOp::Put { key, val })
            .collect();
        backend.write_batch(&ops).unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn recovery_hydrates_only_current_rows_without_replaying_history() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let put = |key: &[u8], value: &[u8]| Mutation::Put {
            table_id: DEFAULT_TABLE_ID,
            key: key.to_vec(),
            value: value.to_vec(),
        };
        let delete = |key: &[u8]| Mutation::Delete {
            table_id: DEFAULT_TABLE_ID,
            key: key.to_vec(),
        };
        let backend = Arc::new(MemBlobs::new());
        let records = [
            test_record_with_mutations(
                1,
                301,
                vec![
                    put(b"phase1f/replay/chain", b"v1"),
                    put(b"phase1f/replay/a", b"one"),
                ],
            ),
            test_record_with_mutations(
                2,
                302,
                vec![
                    put(b"phase1f/replay/chain", b"v2"),
                    delete(b"phase1f/replay/a"),
                    put(b"phase1f/replay/b", b"two"),
                ],
            ),
            test_record_with_mutations(
                3,
                303,
                vec![
                    put(b"phase1f/replay/chain", b"v3"),
                    delete(b"phase1f/replay/b"),
                    put(b"phase1f/replay/c", b"three"),
                ],
            ),
        ];
        for record in &records {
            install_test_record(&backend, record);
        }

        begin_replay_audit();
        let cache = Cache::from_backend(Arc::clone(&backend), CacheOptions::default())
            .expect("recover audited history");
        assert_eq!(
            finish_replay_audit(),
            vec![3, 3],
            "only the two surviving rows are loaded, without replaying older transactions"
        );
        assert_eq!(cache.applied_sequence(), 3);
        assert_eq!(
            cache.get(b"phase1f/replay/chain").unwrap().as_deref(),
            Some(&b"v3"[..])
        );
        assert_eq!(cache.get(b"phase1f/replay/a").unwrap(), None);
        assert_eq!(cache.get(b"phase1f/replay/b").unwrap(), None);
        assert_eq!(
            cache.get(b"phase1f/replay/c").unwrap().as_deref(),
            Some(&b"three"[..])
        );
        cache.close().expect("close audited recovery cache");
    }

    #[test]
    fn default_profile_requires_read_your_writes() {
        assert_eq!(
            CacheOptions::default().log_retention,
            Duration::from_secs(300)
        );
        assert_eq!(CacheOptions::default().gc_interval, Duration::from_secs(10));
        assert!(CacheOptions::default().require_read_my_writes);
        assert_eq!(
            CacheOptions::default().foreground_mode,
            ForegroundMode::Concurrent
        );
        assert_eq!(
            Options::default().durability,
            Durability::Wal,
            "the production cache must not request a per-write disk sync"
        );
    }

    #[test]
    fn gc_options_reject_invalid_time_ranges_and_allow_zero_retention() {
        let mut options = CacheOptions::default();
        options.log_retention = Duration::ZERO;
        assert!(validate_gc_options(options).is_ok());
        options.gc_interval = Duration::ZERO;
        assert!(matches!(
            validate_gc_options(options),
            Err(Error::InvalidGcOptions)
        ));
        options.gc_interval = Duration::MAX;
        assert!(matches!(
            validate_gc_options(options),
            Err(Error::InvalidGcOptions)
        ));
        options.gc_interval = Duration::from_secs(10);
        options.log_retention = Duration::MAX;
        assert!(matches!(
            validate_gc_options(options),
            Err(Error::InvalidGcOptions)
        ));
    }

    #[test]
    fn cache_rejects_wal_disabled_before_opening_any_files() {
        let options = Options {
            durability: Durability::None,
            ..Options::default()
        };
        assert!(matches!(
            Db::open("this-path-must-not-be-opened", options),
            Err(Error::WalRequired)
        ));
    }

    #[cfg(have_mako)]
    #[derive(Debug)]
    struct ApplyThenErrorOnceBlobs {
        inner: mrx_core::fakes::MemBlobs,
        fail_once: AtomicBool,
    }

    #[cfg(have_mako)]
    impl ApplyThenErrorOnceBlobs {
        fn new() -> Self {
            Self {
                inner: mrx_core::fakes::MemBlobs::new(),
                fail_once: AtomicBool::new(true),
            }
        }
    }

    #[cfg(have_mako)]
    impl mrx_core::Blobs for ApplyThenErrorOnceBlobs {
        fn get(&self, key: &[u8]) -> Result<Option<Vec<u8>>, mrx_core::BlobError> {
            self.inner.get(key)
        }

        fn write_batch(
            &self,
            operations: &[mrx_core::BlobOp<'_>],
        ) -> Result<(), mrx_core::BlobError> {
            self.inner.write_batch(operations)?;
            if operations.iter().all(|op| matches!(op, mrx_core::BlobOp::Put { key, .. } if *key == checkpoint::FORMAT_KEY)) { return Ok(()); }
            if self.fail_once.swap(false, Ordering::SeqCst) {
                return Err(mrx_core::BlobError(
                    "injected error after applying backend batch".to_owned(),
                ));
            }
            Ok(())
        }

        fn for_each_key(&self, f: &mut dyn FnMut(&[u8])) -> Result<(), mrx_core::BlobError> {
            self.inner.for_each_key(f)
        }
    }

    #[cfg(have_mako)]
    #[derive(Debug, Default)]
    struct BlockingHealthBlobs {
        inner: mrx_core::fakes::MemBlobs,
        gate: Mutex<(bool, bool)>,
        changed: std::sync::Condvar,
    }

    #[cfg(have_mako)]
    impl BlockingHealthBlobs {
        fn wait_until_entered(&self, timeout: Duration) -> bool {
            let deadline = std::time::Instant::now() + timeout;
            let mut gate = self.gate.lock().unwrap();
            while !gate.0 {
                let now = std::time::Instant::now();
                if now >= deadline {
                    return false;
                }
                let (next, result) = self.changed.wait_timeout(gate, deadline - now).unwrap();
                gate = next;
                if result.timed_out() && !gate.0 {
                    return false;
                }
            }
            true
        }

        fn release(&self) {
            let mut gate = self.gate.lock().unwrap();
            gate.1 = true;
            self.changed.notify_all();
        }
    }

    #[cfg(have_mako)]
    impl mrx_core::Blobs for BlockingHealthBlobs {
        fn get(&self, key: &[u8]) -> Result<Option<Vec<u8>>, mrx_core::BlobError> {
            self.inner.get(key)
        }

        fn write_batch(
            &self,
            operations: &[mrx_core::BlobOp<'_>],
        ) -> Result<(), mrx_core::BlobError> {
            if operations.iter().all(|op| matches!(op, mrx_core::BlobOp::Put { key, .. } if *key == checkpoint::FORMAT_KEY)) { return self.inner.write_batch(operations); }
            let mut gate = self.gate.lock().unwrap();
            gate.0 = true;
            self.changed.notify_all();
            while !gate.1 {
                gate = self.changed.wait(gate).unwrap();
            }
            drop(gate);
            self.inner.write_batch(operations)
        }

        fn for_each_key(&self, f: &mut dyn FnMut(&[u8])) -> Result<(), mrx_core::BlobError> {
            self.inner.for_each_key(f)
        }
    }

    #[cfg(have_mako)]
    #[test]
    fn cache_status_reports_background_retry_and_recovery() {
        use std::sync::Arc;
        use std::time::{Duration, Instant};

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let mut options = CacheOptions::default();
        options.writeback.retry_delay = Duration::from_millis(50);
        let cache = Cache::from_backend(Arc::clone(&backend), options).unwrap();
        backend.fail_next_writes(usize::MAX);

        let initial = cache.status().unwrap();
        assert_eq!(initial.health, CacheHealth::Healthy);
        assert!(initial.is_healthy());
        assert!(initial.background_writer_running);
        assert_eq!(initial.applied_watermark, AppliedWatermark::default());
        assert_eq!(initial.acknowledged_transactions, 0);
        assert_eq!(initial.queued_transactions, 0);
        assert!(initial.writeback_error.is_none());

        cache.put(b"health/retry", b"queued").unwrap();
        let deadline = Instant::now() + Duration::from_secs(2);
        let degraded = loop {
            let status = cache.status().unwrap();
            // Coordinator telemetry is intentionally sampled separately from
            // the dedicated writer's retry counters. Wait until both sides of
            // this background failure have become observable.
            if status.backend_failures != 0 && status.consecutive_background_failures != 0 {
                break status;
            }
            assert!(
                Instant::now() < deadline,
                "background failure did not reach the health snapshot"
            );
            std::thread::yield_now();
        };
        assert_eq!(degraded.health, CacheHealth::Degraded);
        assert!(!degraded.is_healthy());
        assert!(degraded.background_writer_running);
        assert!(degraded.consecutive_background_failures >= 1);
        assert!(degraded.pending_backend_retry.is_some());
        assert_eq!(degraded.active_retryable_failures.len(), 1);
        assert!(matches!(
            degraded.last_failure,
            Some(WritebackFailure {
                kind: WritebackFailureKind::Backend,
                sequence: Some(_),
                ..
            })
        ));
        assert_eq!(degraded.applied_watermark.sequence(), 0);
        assert_eq!(degraded.acknowledged_transactions, 1);
        assert_eq!(degraded.queued_transactions, 1);
        assert!(degraded.writeback_error.is_none());

        backend.fail_next_writes(0);
        assert_eq!(cache.wait_applied().unwrap(), 1);
        let deadline = Instant::now() + Duration::from_secs(2);
        let recovered = loop {
            let status = cache.status().unwrap();
            if status.health == CacheHealth::Healthy {
                break status;
            }
            assert!(
                Instant::now() < deadline,
                "background health did not recover after backend progress"
            );
            std::thread::yield_now();
        };
        assert!(recovered.background_writer_running);
        assert!(recovered.backend_failures >= 1);
        assert_eq!(recovered.consecutive_background_failures, 0);
        assert!(recovered.pending_backend_retry.is_none());
        assert!(recovered.active_retryable_failures.is_empty());
        assert!(recovered.last_failure.is_some());
        assert_eq!(recovered.applied_watermark.sequence(), 1);
        assert_eq!(recovered.acknowledged_transactions, 1);
        assert_eq!(recovered.queued_transactions, 0);
        cache.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn cache_status_retains_caller_driven_apply_failure_and_stopped_writer() {
        use std::sync::Arc;

        let backend = Arc::new(ApplyThenErrorOnceBlobs::new());
        let mut options = CacheOptions::default();
        options.writeback.max_apply_retries = 0;
        let cache = Cache::from_backend(Arc::clone(&backend), options).unwrap();

        cache
            .runtime
            .lock()
            .unwrap()
            .as_mut()
            .unwrap()
            .abort()
            .unwrap();
        cache.put(b"health/caller", b"queued").unwrap();
        let error = cache.wait_applied().unwrap_err();
        let sequence = match error {
            Error::Apply(ApplyError::Backend {
                sequence,
                attempts: 1,
                source,
            }) => {
                assert!(source.0.contains("injected error after applying"));
                sequence
            }
            other => panic!("unexpected caller-driven apply result: {other}"),
        };

        let failed = cache.status().unwrap();
        assert_eq!(failed.health, CacheHealth::Unhealthy);
        assert!(!failed.background_writer_running);
        assert_eq!(failed.backend_failures, 1);
        assert_eq!(failed.pending_backend_retry, Some(sequence));
        assert_eq!(failed.active_retryable_failures, vec![sequence]);
        assert_eq!(failed.acknowledged_transactions, 1);
        assert_eq!(failed.applied_watermark.sequence(), 0);
        assert_eq!(failed.queued_transactions, 1);
        assert_eq!(
            failed.last_failure.as_ref().map(|failure| failure.kind),
            Some(WritebackFailureKind::Backend)
        );
        assert_eq!(
            failed
                .last_failure
                .as_ref()
                .and_then(|failure| failure.sequence),
            Some(sequence)
        );

        assert_eq!(cache.wait_applied().unwrap(), 1);
        let recovered = cache.status().unwrap();
        assert_eq!(recovered.health, CacheHealth::Unhealthy);
        assert!(!recovered.background_writer_running);
        assert_eq!(recovered.backend_failures, 1);
        assert!(recovered.pending_backend_retry.is_none());
        assert!(recovered.active_retryable_failures.is_empty());
        assert!(recovered.last_failure.is_some());
        assert_eq!(recovered.applied_watermark.sequence(), 1);
        assert_eq!(recovered.queued_transactions, 0);
        cache.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn cache_status_observes_backend_call_without_coordinator_lock() {
        use std::sync::{mpsc, Arc};
        use std::time::Duration;

        let backend = Arc::new(BlockingHealthBlobs::default());
        let options = CacheOptions {
            backend_stall_threshold: Duration::from_millis(1),
            ..CacheOptions::default()
        };
        let cache = Cache::from_backend(Arc::clone(&backend), options).unwrap();
        cache.put(b"health/hung", b"queued").unwrap();
        assert!(
            backend.wait_until_entered(Duration::from_secs(1)),
            "background writer did not enter the backend"
        );
        std::thread::sleep(Duration::from_millis(2));

        std::thread::scope(|scope| {
            let (status_tx, status_rx) = mpsc::channel();
            let cache_ref = &cache;
            let observer = scope.spawn(move || status_tx.send(cache_ref.status()).unwrap());
            let status = status_rx.recv_timeout(Duration::from_secs(1));

            // Release before asserting or joining so a lock regression reports
            // a bounded test failure instead of hanging the test process.
            backend.release();
            observer.join().unwrap();

            let status = status
                .expect("status blocked behind the coordinator's backend call")
                .unwrap();
            assert_eq!(status.health, CacheHealth::Degraded);
            assert!(status.background_writer_running);
            let in_progress = status
                .backend_write_in_progress
                .expect("the backend call must be visible");
            let (_, local_sequence) =
                crate::record::split_log_sequence(in_progress.sequence).unwrap();
            assert_eq!(local_sequence, 1);
            assert!(in_progress.elapsed >= status.backend_stall_threshold);
            assert!(status.pending_backend_retry.is_none());
            assert!(status.active_retryable_failures.is_empty());
            assert_eq!(status.applied_watermark.sequence(), 0);
            assert_eq!(status.acknowledged_transactions, 1);
            assert_eq!(status.queued_transactions, 1);
        });

        assert_eq!(cache.wait_applied().unwrap(), 1);
        let recovered = cache.status().unwrap();
        assert_eq!(recovered.health, CacheHealth::Healthy);
        assert!(recovered.backend_write_in_progress.is_none());
        assert_eq!(recovered.queued_transactions, 0);
        cache.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn single_producer_mode_requires_and_exclusively_reuses_its_lease() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let mut options = CacheOptions::default();
        options.foreground_mode = ForegroundMode::SingleProducer;
        options.record_checksum = RecordChecksum::None;
        options.writeback.capacity = 1;
        let cache = Cache::from_backend(Arc::clone(&backend), options).unwrap();

        assert!(matches!(
            cache.transaction(),
            Err(Error::SingleProducerHandleRequired)
        ));
        assert!(matches!(
            cache.put(b"bare", b"rejected"),
            Err(Error::SingleProducerHandleRequired)
        ));

        let mut producer = cache.single_producer().unwrap();
        assert!(matches!(
            cache.single_producer(),
            Err(Error::SingleProducerAlreadyClaimed)
        ));
        producer.put(b"leased", b"value").unwrap();
        assert_eq!(
            producer.get(b"leased").unwrap().as_deref(),
            Some(&b"value"[..])
        );
        assert_eq!(producer.highest_acknowledged_sequence(), 1);
        producer.wait_applied().unwrap();
        drop(producer);

        let mut reacquired = cache.single_producer().unwrap();
        assert!(reacquired.delete(b"leased").unwrap());
        drop(reacquired);
        assert_eq!(cache.wait_applied().unwrap(), 2);
        cache.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn capacity_one_native_holder_survives_retry_and_wraps_three_generations() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let mut options = CacheOptions::default();
        options.foreground_mode = ForegroundMode::SingleProducer;
        options.record_checksum = RecordChecksum::None;
        options.writeback.capacity = 1;
        let max_record_bytes = options.writeback.max_record_bytes;
        let cache = Cache::from_backend(Arc::clone(&backend), options).unwrap();
        let mut producer = cache.single_producer().unwrap();

        backend.fail_next_writes(1);
        assert!(backend.is_failing());
        let writes: [(&[u8], &[u8]); 3] = [
            (b"holder-wrap/a", b"value-one"),
            (b"holder-wrap/b", b"value-two"),
            (b"holder-wrap/c", b"value-three"),
        ];
        for (index, (key, value)) in writes.iter().copied().enumerate() {
            producer.put(key, value).unwrap();
            assert_eq!(
                producer.highest_acknowledged_sequence(),
                (index + 1) as u64,
                "each acknowledged Put must occupy the next holder generation"
            );
        }

        assert_eq!(producer.wait_applied().unwrap(), 3);
        assert_eq!(producer.applied_watermark().sequence(), 3);
        assert!(!backend.is_failing(), "the injected failure was consumed");
        assert_eq!(
            backend.batch_count(),
            4,
            "capacity one permits exactly one successful record per batch"
        );
        assert_eq!(
            backend.op_count(),
            10,
            "format marker plus three log/row/lane batches"
        );

        let snapshot = backend.snapshot();
        let mut log_records = snapshot
            .iter()
            .filter_map(|(key, encoded)| match classify_backend_key(key) {
                BackendKey::Log(_) => Some(
                    CommitRecord::decode(key, encoded, max_record_bytes)
                        .expect("wrapped holder emitted a valid record"),
                ),
                BackendKey::Data { .. }
                | BackendKey::Format
                | BackendKey::Lane(_)
                | BackendKey::Foreign => None,
            })
            .collect::<Vec<_>>();
        log_records.sort_unstable_by_key(|record| record.sequence());
        assert_eq!(log_records.len(), writes.len());
        for (index, (record, (key, value))) in
            log_records.iter().zip(writes.iter().copied()).enumerate()
        {
            assert_eq!(record.sequence().get(), (index + 1) as u64);
            assert_eq!(
                record.mutations(),
                &[Mutation::Put {
                    table_id: DEFAULT_TABLE_ID,
                    key: key.to_vec(),
                    value: value.to_vec(),
                }],
                "holder reuse corrupted generation {}",
                index + 1
            );
            assert!(snapshot.iter().any(|(stored_key, stored_value)| {
                matches!(
                    classify_backend_key(stored_key),
                    BackendKey::Data {
                        table_id: DEFAULT_TABLE_ID,
                        key: stored_key,
                    } if stored_key == key
                ) && checkpoint::decode_row(stored_value).unwrap().value == Some(value)
            }));
        }

        drop(producer);
        assert_eq!(cache.applied_sequence(), 3);
        cache.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn concurrent_mode_rejects_a_single_producer_lease() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let cache =
            Cache::from_backend(Arc::new(MemBlobs::new()), CacheOptions::default()).unwrap();
        assert!(matches!(
            cache.single_producer(),
            Err(Error::SingleProducerModeDisabled)
        ));
        cache.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn native_mako_timestamp_is_carried_into_the_backend_record() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let cache = Cache::from_backend(Arc::clone(&backend), CacheOptions::default()).unwrap();
        cache.put(b"timestamped", b"value").unwrap();
        let sequence = cache.flush().unwrap();

        let (log_key, encoded) = backend
            .snapshot()
            .into_iter()
            .find(|(key, _)| matches!(classify_backend_key(key), BackendKey::Log(_)))
            .expect("one backend transaction record");
        let record = CommitRecord::decode(
            &log_key,
            &encoded,
            CacheOptions::default().writeback.max_record_bytes,
        )
        .unwrap();
        let (_, local_sequence) = split_log_sequence(record.sequence()).unwrap();
        assert_eq!(local_sequence, sequence);
        assert_ne!(record.mako_timestamp().origin(), 0);

        cache.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn unchecked_one_put_cache_path_emits_and_recovers_v6() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let mut options = CacheOptions::default();
        options.record_checksum = RecordChecksum::None;
        let cache = Cache::from_backend(Arc::clone(&backend), options).unwrap();
        cache
            .put(b"unchecked-fast-key", b"unchecked-fast-value")
            .unwrap();
        assert_eq!(cache.flush().unwrap(), 1);

        let (_, encoded) = backend
            .snapshot()
            .into_iter()
            .find(|(key, _)| matches!(classify_backend_key(key), BackendKey::Log(_)))
            .expect("one unchecked backend transaction record");
        assert_eq!(&encoded[..8], b"MAKONOC\0");
        assert_eq!(u16::from_be_bytes([encoded[8], encoded[9]]), 6);

        cache.close().unwrap();
        let reopened = Cache::from_backend(Arc::clone(&backend), options).unwrap();
        assert_eq!(
            reopened.get(b"unchecked-fast-key").unwrap().as_deref(),
            Some(&b"unchecked-fast-value"[..])
        );
        reopened.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn fused_put_then_general_commit_uses_the_next_lane_sequence() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let mut options = CacheOptions::default();
        options.record_checksum = RecordChecksum::None;
        let cache = Cache::from_backend(Arc::clone(&backend), options).unwrap();

        cache.put(b"fused-first", b"one").unwrap();
        let mut general = cache.transaction().unwrap();
        general.put(b"general-second-a", b"two-a").unwrap();
        general.put(b"general-second-b", b"two-b").unwrap();
        general.commit().unwrap();
        assert_eq!(cache.wait_applied().unwrap(), 2);

        let mut local_sequences = backend
            .snapshot()
            .into_iter()
            .filter_map(|(key, encoded)| {
                matches!(classify_backend_key(&key), BackendKey::Log(_)).then(|| {
                    let record = CommitRecord::decode(
                        &key,
                        &encoded,
                        CacheOptions::default().writeback.max_record_bytes,
                    )
                    .unwrap();
                    split_log_sequence(record.sequence()).unwrap().1
                })
            })
            .collect::<Vec<_>>();
        local_sequences.sort_unstable();
        assert_eq!(local_sequences, vec![1, 2]);
        assert_eq!(
            cache.get(b"fused-first").unwrap().as_deref(),
            Some(&b"one"[..])
        );
        assert_eq!(
            cache.get(b"general-second-a").unwrap().as_deref(),
            Some(&b"two-a"[..])
        );
        assert_eq!(
            cache.get(b"general-second-b").unwrap().as_deref(),
            Some(&b"two-b"[..])
        );
        assert_eq!(cache.close().unwrap(), 2);
    }

    #[cfg(have_mako)]
    #[test]
    fn recovery_rejects_a_cache_sequence_gap() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let record = test_record(2, 101, b"gap");
        install_test_record(&backend, &record);

        assert!(matches!(
            Cache::from_backend(backend, CacheOptions::default()),
            Err(Error::BackendStateMismatch)
        ));
    }

    #[cfg(have_mako)]
    #[test]
    fn recovery_accepts_cross_lane_physical_reordering_and_replays_by_timestamp() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let lane_zero = record::worker_log_base(0).unwrap() + 1;
        let lane_one = record::worker_log_base(1).unwrap() + 1;
        let newer = test_record_with_mutations(
            lane_zero,
            402,
            vec![Mutation::Put {
                table_id: DEFAULT_TABLE_ID,
                key: b"cross-lane".to_vec(),
                value: b"newer".to_vec(),
            }],
        );
        let older = test_record_with_mutations(
            lane_one,
            401,
            vec![Mutation::Put {
                table_id: DEFAULT_TABLE_ID,
                key: b"cross-lane".to_vec(),
                value: b"older".to_vec(),
            }],
        );
        // The timestamp winner is materialized last. Physical key order is the
        // opposite order and must not define recovery serialization.
        install_test_record(&backend, &older);
        install_test_record(&backend, &newer);

        begin_replay_audit();
        let cache = Cache::from_backend(Arc::clone(&backend), CacheOptions::default()).unwrap();
        assert_eq!(finish_replay_audit(), vec![lane_zero]);
        assert_eq!(
            cache.get(b"cross-lane").unwrap().as_deref(),
            Some(&b"newer"[..])
        );
        assert_eq!(cache.applied_sequence(), 2);
        cache.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn recovery_rejects_timestamp_reversal_within_a_worker_lane() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let lane_base = record::worker_log_base(0).unwrap();
        let first = test_record_with_mutations(
            lane_base + 1,
            502,
            vec![Mutation::Put {
                table_id: DEFAULT_TABLE_ID,
                key: b"same-worker-lane".to_vec(),
                value: b"newer".to_vec(),
            }],
        );
        let second = test_record_with_mutations(
            lane_base + 2,
            501,
            vec![Mutation::Put {
                table_id: DEFAULT_TABLE_ID,
                key: b"same-worker-lane".to_vec(),
                value: b"older".to_vec(),
            }],
        );
        install_test_record(&backend, &first);
        install_test_record(&backend, &second);

        assert!(matches!(
            Cache::from_backend(backend, CacheOptions::default()),
            Err(Error::BackendStateMismatch)
        ));
    }

    #[cfg(have_mako)]
    #[test]
    fn recovery_replays_delete_against_an_already_absent_local_key() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let lane_sequence = record::worker_log_base(0).unwrap() + 1;
        let delete = test_record_with_mutations(
            lane_sequence,
            601,
            vec![Mutation::Delete {
                table_id: DEFAULT_TABLE_ID,
                key: b"lost-cross-lane-predecessor".to_vec(),
            }],
        );
        install_test_record(&backend, &delete);

        let cache = Cache::from_backend(Arc::clone(&backend), CacheOptions::default())
            .expect("Delete replay must be idempotent when the local key is absent");
        assert_eq!(cache.get(b"lost-cross-lane-predecessor").unwrap(), None);
        assert_eq!(cache.applied_sequence(), 1);
        cache.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn recovery_accepts_sequence_order_opposite_timestamp_order() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let sequence_one_newer = test_record_with_mutations(
            1,
            202,
            vec![Mutation::Put {
                table_id: DEFAULT_TABLE_ID,
                key: b"same-lane-reordered".to_vec(),
                value: b"newer".to_vec(),
            }],
        );
        let sequence_two_older = test_record_with_mutations(
            2,
            201,
            vec![Mutation::Put {
                table_id: DEFAULT_TABLE_ID,
                key: b"same-lane-reordered".to_vec(),
                value: b"older".to_vec(),
            }],
        );

        // Backend application is timestamp-ordered even when the physical log
        // positions are not. Write the older value first to model that result.
        install_test_record(&backend, &sequence_two_older);
        install_test_record(&backend, &sequence_one_newer);

        begin_replay_audit();
        let cache = Cache::from_backend(Arc::clone(&backend), CacheOptions::default()).unwrap();
        assert_eq!(finish_replay_audit(), vec![1]);
        assert_eq!(
            cache.get(b"same-lane-reordered").unwrap().as_deref(),
            Some(&b"newer"[..])
        );
        assert_eq!(cache.applied_watermark().sequence(), 2);
        assert_eq!(
            cache.applied_watermark().mako_timestamp(),
            Some(test_timestamp(202))
        );
        cache.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn recovery_rejects_duplicate_mako_timestamps() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let first = test_record(1, 202, b"first");
        let second = test_record(2, 202, b"duplicate");
        install_test_record(&backend, &first);
        install_test_record(&backend, &second);

        assert!(matches!(
            Cache::from_backend(backend, CacheOptions::default()),
            Err(Error::BackendStateMismatch)
        ));
    }

    #[cfg(have_mako)]
    #[test]
    fn recovery_reconstructs_the_in_memory_applied_frontier() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        const FIRST_TIMESTAMP: u32 = (1 << 25) - 1;
        const FRONTIER_TIMESTAMP: u32 = 1 << 25;
        let backend = Arc::new(MemBlobs::new());
        let first = test_record(1, FIRST_TIMESTAMP, b"first-timestamp");
        let second = test_record(2, FRONTIER_TIMESTAMP, b"sequence-frontier");
        install_test_record(&backend, &first);
        install_test_record(&backend, &second);

        let cache = Cache::from_backend(Arc::clone(&backend), CacheOptions::default()).unwrap();
        assert_eq!(cache.applied_watermark().sequence(), 2);
        assert_eq!(
            cache.applied_watermark().mako_timestamp(),
            Some(test_timestamp(FRONTIER_TIMESTAMP)),
            "the applied timestamp is the greatest timestamp, independent of CacheSeq"
        );

        cache.put(b"after-ordered-recovery", b"new").unwrap();
        cache.wait_applied().unwrap();
        let next = cache.applied_watermark();
        assert_eq!(next.sequence(), 3);
        assert!(
            next.mako_timestamp().unwrap() > test_timestamp(FRONTIER_TIMESTAMP),
            "clock recovery must continue past the serialized CacheSeq frontier"
        );
        cache.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn recovery_advances_mako_timestamp_past_the_recovered_maximum() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        const HOT_PHYSICAL_US_MAX: u64 = ((1u64 << 44) - 1) * 1_000;
        let recovered_timestamp = MakoTimestamp::new(HOT_PHYSICAL_US_MAX, 1_024, 1).unwrap();
        let backend = Arc::new(MemBlobs::new());
        let recovered = crate::record::PreparedCommitRecord::prepare(
            vec![Mutation::Put {
                table_id: DEFAULT_TABLE_ID,
                key: b"recovered".to_vec(),
                value: b"value".to_vec(),
            }],
            CacheOptions::default().writeback.max_record_bytes,
        )
        .unwrap()
        .bind(CommitSeq::new(1).unwrap(), recovered_timestamp)
        .finalize();
        install_test_record(&backend, &recovered);

        let cache = Cache::from_backend(Arc::clone(&backend), CacheOptions::default()).unwrap();
        cache.put(b"after-recovery", b"new").unwrap();
        cache.flush().unwrap();

        let (log_key, encoded) = backend
            .snapshot()
            .into_iter()
            .find(|(key, encoded)| {
                matches!(classify_backend_key(key), BackendKey::Log(_))
                    && CommitRecord::decode(
                        key,
                        encoded,
                        CacheOptions::default().writeback.max_record_bytes,
                    )
                    .is_ok_and(|record| {
                        record
                            .mutations()
                            .iter()
                            .any(|mutation| mutation.key() == b"after-recovery")
                    })
            })
            .expect("post-recovery transaction record");
        let record = CommitRecord::decode(
            &log_key,
            &encoded,
            CacheOptions::default().writeback.max_record_bytes,
        )
        .unwrap();
        assert!(record.mako_timestamp() > recovered_timestamp);

        cache.close().unwrap();
    }

    #[cfg(have_mako)]
    #[test]
    fn recovery_rejects_an_exhausted_recovered_mako_timestamp() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let final_timestamp =
            MakoTimestamp::new(((1u64 << 44) - 1) * 1_000, (1 << 19) - 1, 1).unwrap();
        let final_record = crate::record::PreparedCommitRecord::prepare(
            vec![Mutation::Put {
                table_id: DEFAULT_TABLE_ID,
                key: b"final-timestamp".to_vec(),
                value: b"value".to_vec(),
            }],
            CacheOptions::default().writeback.max_record_bytes,
        )
        .unwrap()
        .bind(CommitSeq::new(1).unwrap(), final_timestamp)
        .finalize();
        install_test_record(&backend, &final_record);

        assert!(matches!(
            Cache::from_backend(backend, CacheOptions::default()),
            Err(Error::Native(LocalError::TimestampExhausted))
        ));
    }

    #[cfg(have_mako)]
    #[test]
    fn pinned_unknown_fail_stops_new_and_in_flight_read_only_transactions() {
        use std::sync::Arc;

        use mrx_core::fakes::MemBlobs;

        let backend = Arc::new(MemBlobs::new());
        let cache = Cache::from_backend(backend, CacheOptions::default()).unwrap();
        let in_flight = cache.transaction().unwrap();

        let lane = cache
            .writeback
            .lane(CommitFence::current_thread_slot())
            .unwrap();
        let pinned = lane
            .writeback()
            .reserve_single(
                lane.producer(),
                vec![Mutation::Put {
                    table_id: DEFAULT_TABLE_ID,
                    key: b"uncertain".to_vec(),
                    value: b"value".to_vec(),
                }],
            )
            .unwrap()
            .bind(test_timestamp(1))
            .unwrap()
            .pin_unknown()
            .unwrap();

        assert!(matches!(
            cache.transaction(),
            Err(Error::Apply(ApplyError::UnknownOutcome { sequence }))
                if sequence == pinned
        ));
        assert!(matches!(
            in_flight.commit(),
            Err(Error::Apply(ApplyError::UnknownOutcome { sequence }))
                if sequence == pinned
        ));

        let status = cache.status().unwrap();
        assert_eq!(status.health, CacheHealth::Unhealthy);
        assert!(status.background_writer_running);
        assert!(matches!(
            status.writeback_error,
            Some(ApplyError::UnknownOutcome { sequence }) if sequence == pinned
        ));
        assert_eq!(status.applied_watermark.sequence(), 0);
        assert_eq!(status.acknowledged_transactions, 0);
        assert_eq!(status.queued_transactions, 1);

        assert!(matches!(
            cache.close(),
            Err(Error::Runtime(RuntimeError::Apply(
                ApplyError::UnknownOutcome { sequence }
            ))) if sequence == pinned
        ));
    }

    #[cfg(have_mako)]
    #[test]
    fn two_readers_drain_one_pinned_writer_and_reject_unknown_outcome() {
        use std::sync::mpsc::{channel, TryRecvError};

        use mrx_core::fakes::MemBlobs;

        let cache = Arc::new(
            Cache::from_backend(Arc::new(MemBlobs::new()), CacheOptions::default()).unwrap(),
        );
        // Attach the owner and allocate its physical lane without publishing
        // a committed record. This fixture drives the same pin_unknown path
        // as the single-reader test, not a simulated native core panic.
        drop(cache.transaction().unwrap());
        let slot = CommitFence::current_thread_slot();
        let writer = cache.commit_fence.enter_writer_slot(slot);
        let lane = cache.writeback.lane(slot).unwrap();
        let mut reserved = lane
            .writeback()
            .reserve_single(
                lane.producer(),
                vec![Mutation::Put {
                    table_id: DEFAULT_TABLE_ID,
                    key: b"uncertain-two-readers".to_vec(),
                    value: b"value".to_vec(),
                }],
            )
            .unwrap()
            .bind(test_timestamp(1))
            .unwrap();

        let (cut_tx, cut_rx) = channel();
        let (done_tx, done_rx) = channel();
        let mut readers = Vec::new();
        for reader_id in 0..2 {
            let cache = Arc::clone(&cache);
            let cut_tx = cut_tx.clone();
            let done_tx = done_tx.clone();
            readers.push(std::thread::spawn(move || {
                let in_flight = cache.transaction().unwrap();
                // Drive the real fence explicitly so both cuts are observable
                // without adding a process-global test hook. The following
                // public commit also executes its own fence and health check.
                cache.commit_fence.close_for_read_only(|| {
                    cache.local.order_record_validation_prefix();
                    cut_tx.send(reader_id).unwrap();
                });
                let result = in_flight.commit();
                done_tx.send(reader_id).unwrap();
                result
            }));
        }
        drop(cut_tx);
        drop(done_tx);
        let first_cut = cut_rx.recv_timeout(Duration::from_secs(5));
        let second_cut = cut_rx.recv_timeout(Duration::from_secs(5));
        let blocked_before_pin = matches!(done_rx.try_recv(), Err(TryRecvError::Empty));
        let pinned = reserved.pin_unknown().unwrap();
        drop(reserved);
        let blocked_until_release = matches!(done_rx.try_recv(), Err(TryRecvError::Empty));
        assert!(matches!(
            cache.transaction(),
            Err(Error::Apply(ApplyError::UnknownOutcome { sequence })) if sequence == pinned
        ));
        // Release and join before checking rendezvous assertions. Restoring
        // the old reader mutex must fail without leaving blocked children.
        drop(writer);
        let outcomes: Vec<_> = readers
            .into_iter()
            .map(|reader| reader.join().unwrap())
            .collect();
        assert!(first_cut.is_ok() && second_cut.is_ok());
        assert_ne!(first_cut.unwrap(), second_cut.unwrap());
        assert!(blocked_before_pin && blocked_until_release);
        for outcome in outcomes {
            assert!(matches!(
                outcome,
                Err(Error::Apply(ApplyError::UnknownOutcome { sequence })) if sequence == pinned
            ));
        }
        let status = cache.status().unwrap();
        assert_eq!(status.health, CacheHealth::Unhealthy);
        assert_eq!(status.applied_watermark.sequence(), 0);
        assert_eq!(status.acknowledged_transactions, 0);
        assert_eq!(status.queued_transactions, 1);
        assert!(matches!(
            status.writeback_error,
            Some(ApplyError::UnknownOutcome { sequence }) if sequence == pinned
        ));
        let cache = Arc::try_unwrap(cache).ok().unwrap();
        assert!(matches!(
            cache.close(),
            Err(Error::Runtime(RuntimeError::Apply(ApplyError::UnknownOutcome { sequence })))
                if sequence == pinned
        ));
    }

    #[cfg(all(have_mako, feature = "engine-sto-test-hooks", panic = "unwind"))]
    #[test]
    fn poisoned_sto_runtime_makes_cache_unhealthy_from_another_worker() {
        const ROLE: &str = "MAKO_CACHE_RUNTIME_HEALTH_ROLE";
        if std::env::var_os(ROLE).is_none() {
            let status = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "tests::poisoned_sto_runtime_makes_cache_unhealthy_from_another_worker",
                ])
                .env(ROLE, "1")
                .status()
                .expect("run runtime-health subprocess");
            assert!(
                status.success(),
                "runtime-health subprocess failed: {status}"
            );
            return;
        }

        fn fail_after_validation(phase: mako_engine::TestCommitPhase, _: Option<MakoTimestamp>) {
            if phase == mako_engine::TestCommitPhase::MakoTimestampAllocated {
                panic!("injected actual STO commit-hook failure");
            }
        }

        let cache = Cache::from_backend(
            std::sync::Arc::new(mrx_core::fakes::MemBlobs::new()),
            CacheOptions::default(),
        )
        .unwrap();
        assert!(cache.status().unwrap().engine_runtime_healthy);
        std::thread::scope(|scope| {
            scope
                .spawn(|| {
                    mako_engine::install_test_commit_observer(fail_after_validation).unwrap();
                    assert!(cache.put(b"poison-runtime", b"uncommitted").is_err());
                    mako_engine::clear_test_commit_observer().unwrap();
                })
                .join()
                .unwrap();
        });
        let status = cache.status().unwrap();
        assert!(!status.engine_runtime_healthy);
        assert_eq!(status.health, CacheHealth::Unhealthy);
        assert_eq!(status.acknowledged_transactions, 0);
        assert_eq!(
            mako_engine::worker_health().unwrap(),
            mako_engine::WorkerHealth::Healthy
        );
        assert!(matches!(
            cache.transaction(),
            Err(Error::Native(LocalError::WorkerPoisoned))
        ));
        let _ = cache.close();
    }

    #[cfg(have_mako)]
    #[test]
    fn preparation_failure_surfaces_native_abort_cleanup_quarantine() {
        const ROLE: &str = "MAKO_CACHE_ABORT_CLEANUP_QUARANTINE_ROLE";
        if std::env::var_os(ROLE).is_none() {
            let status = std::process::Command::new(std::env::current_exe().unwrap())
                .arg("--exact")
                .arg("tests::preparation_failure_surfaces_native_abort_cleanup_quarantine")
                .env(ROLE, "1")
                .status()
                .expect("run abort-cleanup quarantine subprocess");
            assert!(status.success(), "quarantine subprocess failed: {status}");
            return;
        }

        if !mako_engine::features().unwrap().test_cleanup_failures() {
            return;
        }

        std::thread::spawn(|| {
            use std::sync::Arc;

            use mako_engine::{
                arm_test_cleanup_failure, worker_health, TestCleanupBoundary, WorkerHealth,
            };
            use mrx_core::fakes::MemBlobs;

            let backend = Arc::new(MemBlobs::new());
            let cache = Cache::from_backend(backend, CacheOptions::default()).unwrap();
            let mut transaction = cache.transaction().unwrap();
            transaction
                .put(b"preparation-cleanup", b"never-installed")
                .unwrap();

            let lane = cache
                .writeback
                .lane(CommitFence::current_thread_slot())
                .unwrap();
            lane.writeback()
                .reserve_single(
                    lane.producer(),
                    vec![Mutation::Put {
                        table_id: DEFAULT_TABLE_ID,
                        key: b"prior-unknown".to_vec(),
                        value: b"uncertain".to_vec(),
                    }],
                )
                .unwrap()
                .bind(test_timestamp(1))
                .unwrap()
                .pin_unknown()
                .unwrap();
            arm_test_cleanup_failure(TestCleanupBoundary::Abort).unwrap();

            assert!(matches!(
                transaction.commit(),
                Err(Error::Native(LocalError::WorkerPoisoned))
            ));
            assert_eq!(worker_health().unwrap(), WorkerHealth::Poisoned);
            let _ = cache.close();
        })
        .join()
        .unwrap();
    }
}
